<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pivacy Policy</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/cursor.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/jarallex.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.css">
    <link rel="stylesheet" href="assets/css/backToTop.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/odometer-theme-default.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/fontAwesome5Pro.css">
    <link rel="stylesheet" href="assets/css/default.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    <div class="header-banner-bg">
        <div class="container">
            <!------- HEADER TOP START ------->
            <div class="header-top">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <!-- <span class="header-top-address">
                            <i class="fal fa-map-marker-alt"></i> 1901 Thornridge Cir. Shiloh, Hawaii 81063
                        </span> -->
                    </div>

                    <div class="col-md-6">
                        <div class="header-top-contact">
                            <span class="header-top-conatact__phone">
                                <a href="tel:98(000)-96302"><i class="fal fa-phone-alt"></i> +18662616841</a>
                            </span>

                            <span class="header-top-conatact__email">
                                <a href="mailto:info@tvbundlesonline.com"><i class="fal fa-envelope"></i> info@tvbundlesonline.com</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <!------- HEADER TOP END ------->

            <header class="header-area header-1">

                <div class="ba-header-nav-area">
                    <div class="style-2">
                        <div class="ba-header-nav-inner header-bottom">
                            <div class="row align-items-center">

                                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-6">
                                    <div class="ba-header-logo">
                                        <a href="index.php">
                                            <img src="assets/img/logo/logo-3.png" alt="logo">
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xxl-9 col-xl-9 col-lg-9 d-none d-lg-block">
                                    <div class="ba-header-nav-wrapper text-end">
                                        <nav class="ba-header-nav-menu header-bottom__nav" id="mobile-menu">
                                            <ul>
                                                <li>
                                                    <a href="index.php">Home</a>
                                                    <!-- <ul class="submenu index-1-submenu">
                                                        <li><a href="index.php">Home 01</a></li>
                                                        <li><a href="index-2.php">Home 02</a></li>
                                                    </ul> -->
                                                </li>
                                                <!-- <li>
                                                    <a href="about.php">About</a>
                                                </li>
                                                <li>
                                                    <a href="blog.php">Blog</a>
                                                    <ul class="submenu index-1-submenu">
                                                        <li><a href="blog.php">Blog</a></li>
                                                        <li><a href="blog-details.php">Blog Details</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="#0">Pages</a>
                                                    <ul class="submenu index-1-submenu">
                                                        <li><a href="error.php">Error</a></li>
                                                        <li><a href="faq.php">Faq</a></li>
                                                        <li><a href="pricing.php">Pricing</a></li>
                                                        <li><a href="service.php">Service</a></li>
                                                        <li><a href="service-details.php">Service Details</a></li>
                                                        <li><a href="team.php">Team</a></li>
                                                        <li><a href="team-details.php">Team Details</a></li>
                                                    </ul>
                                                </li> -->
                                                <li>
                                                    <a href="privacy-policy.php">Privacy Policy</a>
                                                </li>
                                                <li>
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                            </ul>
                                        </nav>
                                        <div class="ba-header-right-actions index-1-header-btns pl-50">
                                            <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                <i class="fal fa-search"></i>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                <i class="fal fa-shopping-bag"></i>

                                                <span class="index-1-cart-number-popup">
                                                    <span>0</span>
                                                </span>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-6 d-lg-none">
                                    <div class="ba-header-right-actions index-1-header-btns text-end d-block">
                                        <div class="d-none d-md-inline-block">
                                            <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                <i class="fal fa-search"></i>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                <i class="fal fa-shopping-bag"></i>

                                                <span class="index-1-cart-number-popup">
                                                    <span>0</span>
                                                </span>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                            </button>
                                        </div>

                                        <button class="ba-header-right-link btn-index-1 ba-header-sidebar-action">
                                            <i class="fal fa-bars"></i>
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="privacy__title">
<h2> 
    Privacy Policy
</h2>
                </div>
            </header>
            <!-- header area end -->

            <!-- header search start -->
            <div class="ba-search-popup">
                <div class="ba-color-layer"></div>
                <div class="ba-search-popup-inner">
                    <form action="#">
                        <input type="text" placeholder="Search here..." name="search" id="search-input">
                        <button type="submit"><i class="fal fa-search"></i></button>
                    </form>
                </div>
            </div>
            <!-- header search end -->

            <div class="overlay"></div>

            <div class="ba-sidebar-area">
                <div class="ba-sidebar-inner">
                    <div class="ba-sidebar-top">
                        <nav>
                            <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                                <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab"
                                    data-bs-target="#sidebar-nav-1-control" type="button" role="tab"
                                    aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                                <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab"
                                    data-bs-target="#sidebar-nav-2-control" type="button" role="tab"
                                    aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                            </div>
                        </nav>
                    </div>
                    <div class="ba-sidebar-content">
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel"
                                aria-labelledby="ba-sidebar-nav-1">
                                <div class="ba-sidebar-nav-content">
                                    <div class="ba-sidebar-logo-action-wrapper">
                                        <div class="row align-items-center">
                                            <div class="col-md-6 col-7">
                                                <div class="logo">
                                                    <a href="index.php"><img src="assets/img/logo/logo.png"
                                                            alt="logo"></a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-5">
                                                <div class="action">
                                                    <div class="text-end">
                                                        <button class="ba-header-sidebar-action-close"><i
                                                                class="fal fa-times"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ba-sidebar-navigation-main">
                                        <div class="mobile-menu"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel"
                                aria-labelledby="ba-sidebar-nav-2">
                                <div class="ba-sidebar-info-content">
                                    <div class="ba-sidebar-logo-action-wrapper">
                                        <div class="row align-items-center">
                                            <div class="col-md-6 col-7">
                                                <div class="logo">
                                                    <a href="index.php"><img src="assets/img/logo/logo.png"
                                                            alt="logo"></a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-5">
                                                <div class="action">
                                                    <div class="text-end">
                                                        <button class="ba-header-sidebar-action-close"><i
                                                                class="fal fa-times"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p>We must explain to you how all seds this mistakens idea off denouncing pleasures
                                        and praising pain was born and I will give you a completed accounts of the
                                        system and expound.</p>
                                    <button type="submit" class="ba-submit-btn">Contact Us</button>
                                    <div class="ba-header-right-actions text-end mt-35">
                                        <button class="ba-header-right-link ba-header-search-btn"><i
                                                class="fal fa-search"></i></button>
                                        <a class="ba-header-right-link" href="index.php"><i
                                                class="fal fa-user"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!----------------- BANNER SECTION STARTS ----------------->
     
            <!----------------- BANNER SECTION ENDS ----------------->

        </div>
    </div>
    <section class="privacy__policy mt-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-10">
                    <div class="privacy__title">
                        <h3>
                            Privacy Policy
                        </h3>
                        <p>
                            Ensure that you agree to all of tvcablebundlesonline.com's processing before moving forward by reading the entire document.
                        </p>
                        <p>
                            The provisions of this agreement and the data above contain the whole understanding between the Customers and the local cable company.
                            The real servers don’t have to deny any affiliations because we are a recognised service firm.
                            Your cable provider maintains the right to reject, modify, or remove any Customer IDs, Passwords, or PINS that it deems unsuitable or undesirable.
                        </p>
                        <p>
                            The customer is aware that any modifications to the previously mentioned information must be immediately reported to a local cable provider.
                        </p>
                        <p>
                            Due to equipment upgrades, relocations, repairs, and other similar operations necessary for the proper operation of the service, the service to some or all clients may be temporarily interrupted or diminished. If a planned interruption does occur, adequate advance notice will be provided.
                        </p>
                        <p>
                            The user won’t in any way abuse the information and tools made available through the cable service near me, the payment service. The Client accepts and agrees to abide by all of the aforementioned privacy policies by signing this paper.
                        </p>
                    </div>
                    <div class="privacy__content">
                        <h4>
                            Legit Security
                        </h4>
                        <p>
                            Your confidential information is protected. Your data is only accessed if it is required for processing or to finish a task. The database allows the permitted people to access your personal data. Because the database only contains your protected sensitive information, we must simultaneously ensure rigidity and dependability.
                        </p>
                        <h4>
                            Legit Disclaimer
                        </h4>
                        <p>
                            We reserve the right to disclose your personal information if necessary to comply with a court order, subpoena, or other legal process served on us for services, protect our rights, or both.
                        </p>
                        <h4>
                            Queries
                        </h4>
                        <p>
        
                            This privacy statement contains a lot of information to help you understand it. Please send us an email at info@tvbundlesonline.com if you have any additional worries or inquiries about our privacy practices or how we use your information.
        
        
                        </p>
                    </div>
                </div>
            </div>
        </div>
        </section>

        <footer id="footer-section">
            <div class="container">
    
                <!-- FOOTER ONE STARTS HERE -->
                <div class="footer-one mt-4">
                    <div class="row justify-content-between">
                        <div class="col-xxl-4 col-xl-5 col-lg-6">
                            <!-- <div class="footer-heading">
                                <h3>We Are Your Instagram Best Solution</h3>
                            </div> -->
                        </div>
    
                        <!-- <div class="col-xxl-5 col-xl-6 col-lg-6">
                            <div class="footer-img-container">
                                <a href="assets/img/bg/service.png" class="image-popups">
                                    <img src="assets/img/bg/service.png" alt="girls-using-phone" class="footer-img">
                                </a>
                                <a href="assets/img/about/about-1.jpg" class="image-popups">
                                    <img src="assets/img/about/about-1.jpg" alt="2 people watching tab" class="footer-img">
                                </a>
                                <a href="assets/img/blog/blog-box-1.png" class="image-popups">
                                    <img src="assets/img/blog/blog-box-1.png" alt="girl-lying" class="footer-img">
                                </a>
                                <a href="assets/img/blog/blog-details-1.jpg" class="image-popups">
                                    <img src="assets/img/blog/blog-details-1.jpg" alt="people using laptop"
                                        class="footer-img">
                                </a>
                            </div>
                        </div> -->
                    </div>
                </div>
                <!-- FOOTER ONE ENDS HERE -->
    
    
                <!-- FOOTER TWO STARTS HERE -->
                <div class="footer-two">
                    <div class="row justify-content-xl-between justify-content-center">
                        <div class="col-xl-3 col-lg-4 col-md-6">
                            <div class="company-info">
                                <img src="assets/img/logo/logo-3.png" alt="logo" class="footer-two__logo">
    
                                <div class="company-info__txt">
                                    <h3 class="ba-footer-widget-title footer-two-widget__title">
                                        CUSTOMER SERVICE
                                    </h3>
                                    <p>
                                        At Tv Bundles Online, we pride ourselves on delivering top-notch customer service
                                        that exceeds our clients' expectations.
                                    </p>
                                    <!-- <span>O PBox 1622 Vissaosang Street West </span> -->
    
                                    <!-- <div class="company__numbers">
                                        <a href="tel:9145789658424">+9145789658424 ,</a>
                                        <a href="tel:6157845625">+6157845625</a>
                                    </div> -->
    
                                    <!-- <span>minimart@domain.com</span>
                                    <span>Opening Hours : 8.00AM - 21.00AM</span>
                                    <span>Sunday - Friday</span> -->
                                </div>
                            </div>
                        </div>
    
                        <div class="col-xl-2 col-lg-3 col-6">
                            <div class="ba-footer-widget footer-two-widget">
                                <h3 class="ba-footer-widget-title footer-two-widget__title">LET US HELP YOU</h3>
                                <p>
                                    Ask a question
                                    Request support
                                    Learn more about our products and services
                                    Get started with a custom solution
                                </p>
                            </div>
                        </div>
    
                        <div class="col-xl-2 col-lg-3 col-6">
                            <div class="ba-footer-widget footer-two-widget">
                                <h3 class="ba-footer-widget-title footer-two-widget__title">INFORMATION </h3>
                                <ul>
                                    <li><a href="privacy-policy.php">Pivacy Policy</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                    <!-- <li><a href="blog-details.php">Blog Details</a></li>
                                    <li><a href="team.php">Team</a></li>
                                    <li><a href="team-details.php">Team Details</a></li> -->
                                </ul>
                            </div>
                        </div>
    
                        <div class="col-xl-3 col-lg-4 col-md-6 col-8">
                            <div class="ba-footer-widget footer-two-widget footer-two-widget--last pr-50">
                                <h3 class="ba-footer-widget-title footer-two-widget__title">OUR SHOP</h3>
                                <div class="ba-footer-widget-working-hours-list footer-two-widget__working-hours">
                                  <p>
                                    Experience crystal-clear picture quality and reliable service with our state-of-the-art cable technology.
    
                                  </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- FOOTER TWO ENDS HERE -->
    
                <!-- FOOTER THREE STARTS HERE -->
                <div class="footer-three pt-35 pb-40">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="ba-footer-copyright-text footer-three__copyright-text">Copyright &copy; 2022 All
                                rights reserved.</p>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                            <img src="assets/img/payment-method/payment-method.png" alt="logo" class="payment-methods">
                        </div>
                    </div>
                </div>
                <!-- FOOTER THREE ENDS HERE -->
            </div>
        </footer>
    
</body>
</html>