<!doctype html>
<html class="no-js" lang="zxx">
   
<head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Contact Us</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Place favicon.ico in the root directory -->
      <!-- <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png"> -->
      <!-- CSS here -->
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/meanmenu.css">
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <link rel="stylesheet" href="assets/css/cursor.css">
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/jarallex.css">
      <link rel="stylesheet" href="assets/css/swiper-bundle.css">
      <link rel="stylesheet" href="assets/css/backToTop.css">
      <link rel="stylesheet" href="assets/css/flaticon.css">
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <link rel="stylesheet" href="assets/css/odometer-theme-default.css">
      <link rel="stylesheet" href="assets/css/nice-select.css">
      <link rel="stylesheet" href="assets/css/fontAwesome5Pro.css">
      <link rel="stylesheet" href="assets/css/default.css">
      <link rel="stylesheet" href="assets/css/main.css">
   </head>
   <body>

      <!-- header area start -->
      <div class="header-banner-bg">
         <div class="container">
             <!------- HEADER TOP START ------->
             <div class="header-top">
                 <div class="row justify-content-between">
                     <!-- <div class="col-md-6">
                         <span class="header-top-address">
                             <i class="fal fa-map-marker-alt"></i> 1901 Thornridge Cir. Shiloh, Hawaii 81063
                         </span>
                     </div> -->
 
                     <div class="col-md-6">
                         <div class="header-top-contact">
                             <span class="header-top-conatact__phone">
                                 <a href="tel:98(000)-96302"><i class="fal fa-phone-alt"></i> +18662616841</a>
                             </span>
 
                             <span class="header-top-conatact__email">
                                 <a href="mailto:info@tvbundlesonline.com"><i class="fal fa-envelope"></i> info@tvbundlesonline.com</a>
                             </span>
                         </div>
                     </div>
                 </div>
             </div>
             <!------- HEADER TOP END ------->
 
             <header class="header-area header-1">
 
                 <div class="ba-header-nav-area">
                     <div class="style-2">
                         <div class="ba-header-nav-inner header-bottom">
                             <div class="row align-items-center">
 
                                 <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-6">
                                     <div class="ba-header-logo">
                                         <a href="index.php">
                                             <img src="assets/img/logo/logo-3.png" alt="logo">
                                         </a>
                                     </div>
                                 </div>
 
                                 <div class="col-xxl-9 col-xl-9 col-lg-9 d-none d-lg-block">
                                     <div class="ba-header-nav-wrapper text-end">
                                         <nav class="ba-header-nav-menu header-bottom__nav" id="mobile-menu">
                                             <ul>
                                                 <li>
                                                     <a href="index.php">Home</a>
                                                     <!-- <ul class="submenu index-1-submenu">
                                                         <li><a href="index.php">Home 01</a></li>
                                                         <li><a href="index-2.php">Home 02</a></li>
                                                     </ul> -->
                                                 </li>
                                                 <!-- <li>
                                                     <a href="about.php">About</a>
                                                 </li>
                                                 <li>
                                                     <a href="blog.php">Blog</a>
                                                     <ul class="submenu index-1-submenu">
                                                         <li><a href="blog.php">Blog</a></li>
                                                         <li><a href="blog-details.php">Blog Details</a></li>
                                                     </ul>
                                                 </li>
                                                 <li>
                                                     <a href="#0">Pages</a>
                                                     <ul class="submenu index-1-submenu">
                                                         <li><a href="error.php">Error</a></li>
                                                         <li><a href="faq.php">Faq</a></li>
                                                         <li><a href="pricing.php">Pricing</a></li>
                                                         <li><a href="service.php">Service</a></li>
                                                         <li><a href="service-details.php">Service Details</a></li>
                                                         <li><a href="team.php">Team</a></li>
                                                         <li><a href="team-details.php">Team Details</a></li>
                                                     </ul>
                                                 </li> -->
                                                 <li>
                                                     <a href="privacy-policy.php">Privacy Policy</a>
                                                 </li>
                                                 <li>
                                                     <a href="contact.php">Contact</a>
                                                 </li>
                                             </ul>
                                         </nav>
                                         <div class="ba-header-right-actions index-1-header-btns pl-50">
                                             <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                 <i class="fal fa-search"></i>
                                             </button>
 
                                             <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                 <i class="fal fa-shopping-bag"></i>
 
                                                 <span class="index-1-cart-number-popup">
                                                     <span>0</span>
                                                 </span>
                                             </button>
 
                                             <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                             </button>
                                         </div>
                                     </div>
                                 </div>
 
                                 <div class="col-md-6 col-6 d-lg-none">
                                     <div class="ba-header-right-actions index-1-header-btns text-end d-block">
                                         <div class="d-none d-md-inline-block">
                                             <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                 <i class="fal fa-search"></i>
                                             </button>
 
                                             <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                 <i class="fal fa-shopping-bag"></i>
 
                                                 <span class="index-1-cart-number-popup">
                                                     <span>0</span>
                                                 </span>
                                             </button>
 
                                             <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                             </button>
                                         </div>
 
                                         <button class="ba-header-right-link btn-index-1 ba-header-sidebar-action">
                                             <i class="fal fa-bars"></i>
                                         </button>
                                     </div>
                                 </div>
 
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="privacy__title">
 <h2> 
    Contact Us
 </h2>
                 </div>
             </header>
             <!-- header area end -->
 
             <!-- header search start -->
             <div class="ba-search-popup">
                 <div class="ba-color-layer"></div>
                 <div class="ba-search-popup-inner">
                     <form action="#">
                         <input type="text" placeholder="Search here..." name="search" id="search-input">
                         <button type="submit"><i class="fal fa-search"></i></button>
                     </form>
                 </div>
             </div>
             <!-- header search end -->
 
             <div class="overlay"></div>
 
             <div class="ba-sidebar-area">
                 <div class="ba-sidebar-inner">
                     <div class="ba-sidebar-top">
                         <nav>
                             <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                                 <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab"
                                     data-bs-target="#sidebar-nav-1-control" type="button" role="tab"
                                     aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                                 <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab"
                                     data-bs-target="#sidebar-nav-2-control" type="button" role="tab"
                                     aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                             </div>
                         </nav>
                     </div>
                     <div class="ba-sidebar-content">
                         <div class="tab-content" id="nav-tabContent">
                             <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel"
                                 aria-labelledby="ba-sidebar-nav-1">
                                 <div class="ba-sidebar-nav-content">
                                     <div class="ba-sidebar-logo-action-wrapper">
                                         <div class="row align-items-center">
                                             <div class="col-md-6 col-7">
                                                 <div class="logo">
                                                     <a href="index.php"><img src="assets/img/logo/logo.png"
                                                             alt="logo"></a>
                                                 </div>
                                             </div>
                                             <div class="col-md-6 col-5">
                                                 <div class="action">
                                                     <div class="text-end">
                                                         <button class="ba-header-sidebar-action-close"><i
                                                                 class="fal fa-times"></i></button>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="ba-sidebar-navigation-main">
                                         <div class="mobile-menu"></div>
                                     </div>
                                 </div>
                             </div>
                             <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel"
                                 aria-labelledby="ba-sidebar-nav-2">
                                 <div class="ba-sidebar-info-content">
                                     <div class="ba-sidebar-logo-action-wrapper">
                                         <div class="row align-items-center">
                                             <div class="col-md-6 col-7">
                                                 <div class="logo">
                                                     <a href="index.php"><img src="assets/img/logo/logo.png"
                                                             alt="logo"></a>
                                                 </div>
                                             </div>
                                             <div class="col-md-6 col-5">
                                                 <div class="action">
                                                     <div class="text-end">
                                                         <button class="ba-header-sidebar-action-close"><i
                                                                 class="fal fa-times"></i></button>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <p>We must explain to you how all seds this mistakens idea off denouncing pleasures
                                         and praising pain was born and I will give you a completed accounts of the
                                         system and expound.</p>
                                     <button type="submit" class="ba-submit-btn">Contact Us</button>
                                     <div class="ba-header-right-actions text-end mt-35">
                                         <button class="ba-header-right-link ba-header-search-btn"><i
                                                 class="fal fa-search"></i></button>
                                         <a class="ba-header-right-link" href="index.php"><i
                                                 class="fal fa-user"></i></a>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
 
 
             <!----------------- BANNER SECTION STARTS ----------------->
      
             <!----------------- BANNER SECTION ENDS ----------------->
 
         </div>
     </div>
      <!-- header area end -->
      <!-- header search start -->
      <div class="ba-search-popup">
         <div class="ba-color-layer"></div>
         <div class="ba-search-popup-inner">
            <form action="#">
               <input type="text" placeholder="Search here..." name="search" id="search-input">
               <button type="submit"><i class="fal fa-search"></i></button>
            </form>
         </div>
      </div>
      <!-- header search end -->
      <div class="overlay"></div>
      <!-- sidebar area start -->
      <div class="ba-sidebar-area">
         <div class="ba-sidebar-inner">
            <div class="ba-sidebar-top">
               <nav>
                  <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                  <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab" data-bs-target="#sidebar-nav-1-control" type="button" role="tab" aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                  <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab" data-bs-target="#sidebar-nav-2-control" type="button" role="tab" aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                  </div>
               </nav>
            </div>
            <div class="ba-sidebar-content">
               <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-1">
                     <div class="ba-sidebar-nav-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="ba-sidebar-navigation-main">
                           <div class="mobile-menu"></div>
                        </div>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-2">
                     <div class="ba-sidebar-info-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <p>We must explain to you how all seds this mistakens idea off denouncing pleasures and praising pain was born and I will give you a completed accounts of the system and expound.</p>
                        <button type="submit" class="ba-submit-btn">Contact Us</button>
                        <div class="ba-header-right-actions text-end mt-35">
                           <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                              <a class="ba-header-right-link" href="index.php"><i class="fal fa-user"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- sidebar area end -->
      <main>
        <!-- breadcrumb area start -->
   
        <!-- breadcrumb area end -->
        <!-- contact area start -->
        <div class="contact-area pt-120 pb-120">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-xl-6 col-lg-6 mb-50 mb-lg-0">
                        <div class="ba-contact-left-content">
                            <div class="ba-section-title-wrapper-top pb-40">
                                <div class="ba-section-title-wrapper pb-10">
                                    <h5 class="ba-section-subtitle wow fadeInUp" data-wow-delay=".1s"> Contact Wlth Us</h5>
                                    <h3 class="ba-section-title wow fadeInUp"  data-wow-delay=".2s">Get In Touch!</h3>
                                 </div>
                                 <p class="ba-mb-0">Get in Touch! Contact with us Get in Touch! Contact with us</p>
                            </div>
                             <div class="ba-contact-left-content-list">
                                <ul>
                                    <li>
                                        <!-- <div class="icon">
                                            <i class="fal fa-map-marker-alt"></i>
                                        </div> -->
                                        <!-- <div class="content">
                                            <h5 class="ba-contact-left-title"><a href="https://goo.gl/maps/zubhQ3QbiUD2WSdG8" target="_blank">Address</a></h5>
                                            <p class="ba-contact-left-value">7515 Carriage Court, Coachella, CA, 92236 USA</p>
                                        </div> -->
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <i class="fal fa-mobile"></i>
                                        </div>
                                        <div class="content">
                                            <h5 class="ba-contact-left-title"><a href="tel:123-456-7890">Call Us Today</a></h5>
                                            <a href="tel:+18662616841" class="ba-contact-left-value">+1 866 261 6841</a>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <i class="fal fa-envelope"></i>
                                        </div>
                                        <div class="content">
                                            <h5 class="ba-contact-left-title"><a href="mailto:kenray@nurcodes.com">Email Us</a></h5>
                                            <a href="mailto:kenray@nurcodes.com" class="ba-contact-left-value">info@tvbundlesonline.com</a>
                                        </div>
                                    </li>
                                </ul>
                             </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                        <form action="#">
                            <div class="row">
                               <div class="col-xxl-6 col-xl-6 col-lg-6">
                                  <div class="ba-blog-comment-input-wrap mb-30">
                                     <input type="text" placeholder="Your Nome">
                                  </div>
                               </div>
                               <div class="col-xxl-6 col-xl-6 col-lg-6">
                                  <div class="ba-blog-comment-input-wrap mb-30">
                                     <input type="email" placeholder="Email Address">
                                  </div>
                               </div>
                               <div class="col-xxl-6 col-xl-6 col-lg-6">
                                  <div class="ba-blog-comment-input-wrap mb-30">
                                     <input type="number" placeholder="Phone Number">
                                  </div>
                               </div>
                               <div class="col-xxl-6 col-xl-6 col-lg-6">
                                  <div class="ba-blog-comment-input-wrap mb-30">
                                     <input type="text" placeholder="Subject">
                                  </div>
                               </div>
                               <div class="col-xxl-12">
                                  <div class="ba-blog-comment-input-wrap mb-30">
                                     <textarea name="comment_text" id="comment_text" placeholder="Your Comments*"></textarea>
                                  </div>
                               </div>
                               <div class="col-xxl-12">
                                  <button class="ba-submit-btn" type="submit">Send Message</button>
                               </div>
                            </div>
                         </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- contact area end -->
        <!-- contact map area start -->
        <!-- <div class="ba-contact-map-area has-ba-contact-overlay">
            <div class="ba-contact-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13004071.476136694!2d-104.65623853113215!3d37.275644573063445!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2z4Kau4Ka-4Kaw4KeN4KaV4Ka_4KaoIOCmr-CngeCmleCnjeCmpOCmsOCmvuCmt-CnjeCmn-CnjeCmsA!5e0!3m2!1sbn!2sbd!4v1668775587168!5m2!1sbn!2sbd" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div> -->
        <!-- contact map area end -->
      </main>
      <!-- footer area start -->
      <footer id="footer-section">
         <div class="container">
 
             <!-- FOOTER ONE STARTS HERE -->
             <div class="footer-one mt-4">
                 <div class="row justify-content-between">
                     <div class="col-xxl-4 col-xl-5 col-lg-6">
                         <!-- <div class="footer-heading">
                             <h3>We Are Your Instagram Best Solution</h3>
                         </div> -->
                     </div>
 
                     <!-- <div class="col-xxl-5 col-xl-6 col-lg-6">
                         <div class="footer-img-container">
                             <a href="assets/img/bg/service.png" class="image-popups">
                                 <img src="assets/img/bg/service.png" alt="girls-using-phone" class="footer-img">
                             </a>
                             <a href="assets/img/about/about-1.jpg" class="image-popups">
                                 <img src="assets/img/about/about-1.jpg" alt="2 people watching tab" class="footer-img">
                             </a>
                             <a href="assets/img/blog/blog-box-1.png" class="image-popups">
                                 <img src="assets/img/blog/blog-box-1.png" alt="girl-lying" class="footer-img">
                             </a>
                             <a href="assets/img/blog/blog-details-1.jpg" class="image-popups">
                                 <img src="assets/img/blog/blog-details-1.jpg" alt="people using laptop"
                                     class="footer-img">
                             </a>
                         </div>
                     </div> -->
                 </div>
             </div>
             <!-- FOOTER ONE ENDS HERE -->
 
 
             <!-- FOOTER TWO STARTS HERE -->
             <div class="footer-two">
                 <div class="row justify-content-xl-between justify-content-center">
                     <div class="col-xl-3 col-lg-4 col-md-6">
                         <div class="company-info">
                             <img src="assets/img/logo/logo-3.png" alt="logo" class="footer-two__logo">
 
                             <div class="company-info__txt">
                                 <h3 class="ba-footer-widget-title footer-two-widget__title">
                                     CUSTOMER SERVICE
                                 </h3>
                                 <p>
                                     At Tv Bundles Online, we pride ourselves on delivering top-notch customer service
                                     that exceeds our clients' expectations.
                                 </p>
                                 <!-- <span>O PBox 1622 Vissaosang Street West </span> -->
 
                                 <!-- <div class="company__numbers">
                                     <a href="tel:9145789658424">+9145789658424 ,</a>
                                     <a href="tel:6157845625">+6157845625</a>
                                 </div> -->
 
                                 <!-- <span>minimart@domain.com</span>
                                 <span>Opening Hours : 8.00AM - 21.00AM</span>
                                 <span>Sunday - Friday</span> -->
                             </div>
                         </div>
                     </div>
 
                     <div class="col-xl-2 col-lg-3 col-6">
                         <div class="ba-footer-widget footer-two-widget">
                             <h3 class="ba-footer-widget-title footer-two-widget__title">LET US HELP YOU</h3>
                             <p>
                                 Ask a question
                                 Request support
                                 Learn more about our products and services
                                 Get started with a custom solution
                             </p>
                         </div>
                     </div>
 
                     <div class="col-xl-2 col-lg-3 col-6">
                         <div class="ba-footer-widget footer-two-widget">
                             <h3 class="ba-footer-widget-title footer-two-widget__title">INFORMATION </h3>
                             <ul>
                                 <li><a href="privacy-policy.php">Pivacy Policy</a></li>
                                 <li><a href="contact.php">Contact Us</a></li>
                                 <!-- <li><a href="blog-details.php">Blog Details</a></li>
                                 <li><a href="team.php">Team</a></li>
                                 <li><a href="team-details.php">Team Details</a></li> -->
                             </ul>
                         </div>
                     </div>
 
                     <div class="col-xl-3 col-lg-4 col-md-6 col-8">
                         <div class="ba-footer-widget footer-two-widget footer-two-widget--last pr-50">
                             <h3 class="ba-footer-widget-title footer-two-widget__title">OUR SHOP</h3>
                             <div class="ba-footer-widget-working-hours-list footer-two-widget__working-hours">
                               <p>
                                 Experience crystal-clear picture quality and reliable service with our state-of-the-art cable technology.
 
                               </p>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <!-- FOOTER TWO ENDS HERE -->
 
             <!-- FOOTER THREE STARTS HERE -->
             <div class="footer-three pt-35 pb-40">
                 <div class="row">
                     <div class="col-md-6">
                         <p class="ba-footer-copyright-text footer-three__copyright-text">Copyright &copy; 2022 All
                             rights reserved.</p>
                     </div>
                     <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                         <img src="assets/img/payment-method/payment-method.png" alt="logo" class="payment-methods">
                     </div>
                 </div>
             </div>
             <!-- FOOTER THREE ENDS HERE -->
         </div>
     </footer>
      <!-- footer area end -->  

      <!-- back to top start -->
      <div class="progress-wrap">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>
      <!-- back to top end -->
      

      <!-- JS here -->
      <script src="assets/js/jquery-3.6.0.min.js"></script>
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/meanmenu.js"></script>
      <script src="assets/js/swiper-bundle.min.js"></script>
      <script src="assets/js/magnific-popup.min.js"></script>
      <script src="assets/js/jquery-ui-slider-range.js"></script>
      <script src="assets/js/appair.min.js"></script>
      <script src="assets/js/odometer.min.js"></script>
      <script src="assets/js/backToTop.js"></script>
      <script src="assets/js/nice-select.min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/imagesloaded.pkgd.min.js"></script>
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/main.js"></script>
   </body>

</html>
