<!doctype html>
<html class="no-js" lang="zxx">
   
<head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Nafiab - Broadband & Internet HTML Template</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Place favicon.ico in the root directory -->
      <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
      <!-- CSS here -->
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/meanmenu.css">
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <link rel="stylesheet" href="assets/css/cursor.css">
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/jarallex.css">
      <link rel="stylesheet" href="assets/css/swiper-bundle.css">
      <link rel="stylesheet" href="assets/css/backToTop.css">
      <link rel="stylesheet" href="assets/css/flaticon.css">
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <link rel="stylesheet" href="assets/css/odometer-theme-default.css">
      <link rel="stylesheet" href="assets/css/nice-select.css">
      <link rel="stylesheet" href="assets/css/fontAwesome5Pro.css">
      <link rel="stylesheet" href="assets/css/default.css">
      <link rel="stylesheet" href="assets/css/main.css">
   </head>
   <body>

      <!-- header area start -->
         <header class="header-area header-1">
            <div class="ba-header-top-area bg-theme">
               <div class="container">
                  <div class="ba-header-top-content">
                     <div class="row">
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                           <a href="https://goo.gl/maps/qo6NG3ZXbN6bbev69" class="ba-header-top-list">
                              <i class="fal fa-location"></i>
                              <span>1901 Thornridge Cir. Shiloh, Hawaii 81063</span>
                           </a>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                           <div class="text-center text-md-end ba-header-top-right">
                              <a href="tel:98(000)-96302" class="ba-header-top-list">
                                 <i class="fal fa-phone-alt"></i>
                                 <span>+98(000)-96302</span>
                              </a>
                              <a href="mailto:info@tvbundlesonline.com" class="ba-header-top-list">
                                 <i class="fal fa-envelope"></i>
                                 <span>info@tvbundlesonline.com</span>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="ba-header-nav-area">
               <div class="container style-2">
                  <div class="ba-header-nav-inner">
                     <div class="row align-items-center">
                        <div class="col-xxl-4 col-6 col-xl-4 col-lg-3 col-md-6">
                           <div class="ba-header-logo">
                              <a href="index.php">
                                 <img src="assets/img/logo/logo.png" alt="">
                              </a>
                           </div>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-9 d-none d-lg-block">
                           <div class="ba-header-nav-wrapper text-end">
                              <nav class="ba-header-nav-menu" id="mobile-menu">
                                 <ul> 
                                    <li>
                                       <a href="index.php">Home</a>
                                       <ul class="submenu">
                                          <li><a href="index.php">Home 01</a></li>
                                          <li><a href="index-2.php">Home 02</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="about.php">About</a>
                                    </li>
                                    <li>
                                       <a href="blog.php">Blog</a>
                                       <ul class="submenu">
                                          <li><a href="blog.php">Blog</a></li>
                                          <li><a href="blog-details.php">Blog Details</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="#0">Pages</a>
                                       <ul class="submenu">
                                          <li><a href="error.php">Error</a></li>
                                          <li><a href="faq.php">Faq</a></li>
                                          <li><a href="pricing.php">Pricing</a></li>
                                          <li><a href="service.php">Service</a></li>
                                          <li><a href="service-details.php">Service Details</a></li>
                                          <li><a href="team.php">Team</a></li>
                                          <li><a href="team-details.php">Team Details</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="contact.php">Contact</a>
                                    </li>
                                 </ul>
                              </nav>
                              <div class="ba-header-right-actions pl-50">
                                 <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                                 <a class="ba-header-right-link" href="contact.php"><i class="fal fa-user"></i></a>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-6 d-lg-none">
                           <div class="ba-header-right-actions text-end d-block">
                              <div class="d-none d-md-inline-block">
                                 <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                                 <a class="ba-header-right-link" href="contact.php"><i class="fal fa-user"></i></a>
                              </div>
                              <a class="ba-header-right-link ba-header-sidebar-action" href="#0"><i class="fal fa-bars"></i></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
      <!-- header area end -->
      <!-- header search start -->
      <div class="ba-search-popup">
         <div class="ba-color-layer"></div>
         <div class="ba-search-popup-inner">
            <form action="#">
               <input type="text" placeholder="Search here..." name="search" id="search-input">
               <button type="submit"><i class="fal fa-search"></i></button>
            </form>
         </div>
      </div>
      <!-- header search end -->
      <div class="overlay"></div>
      <!-- sidebar area start -->
      <div class="ba-sidebar-area">
         <div class="ba-sidebar-inner">
            <div class="ba-sidebar-top">
               <nav>
                  <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                  <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab" data-bs-target="#sidebar-nav-1-control" type="button" role="tab" aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                  <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab" data-bs-target="#sidebar-nav-2-control" type="button" role="tab" aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                  </div>
               </nav>
            </div>
            <div class="ba-sidebar-content">
               <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-1">
                     <div class="ba-sidebar-nav-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="ba-sidebar-navigation-main">
                           <div class="mobile-menu"></div>
                        </div>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-2">
                     <div class="ba-sidebar-info-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <p>We must explain to you how all seds this mistakens idea off denouncing pleasures and praising pain was born and I will give you a completed accounts of the system and expound.</p>
                        <button type="submit" class="ba-submit-btn">Contact Us</button>
                        <div class="ba-header-right-actions text-end mt-35">
                           <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                              <a class="ba-header-right-link" href="index.php"><i class="fal fa-user"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- sidebar area end -->
      <main>
        <!-- breadcrumb area start -->
        <div class="ba-breadcrumb-area bg-default ba-breadcrumb-reverce-space has-breadcrumb-overlay " data-background="assets/img/bg/breadcrumb.jpg">
            <div class="container style-2">
                <div class="ba-breadcrumb-inner-wrapper pl-40 pt-140 pb-115 pr-40 p-rel">
                  <h1 class="ba-breadcrumb-title">Blog Standard</h1>
                  <div class="ba-breadcrumb-navs ba-breadcrumb-navs-has-pos">
                     <a href="index.php">Home</a>
                     <span class="current">Blog Standard</span>
                  </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb area end -->
        <!-- blog area start -->
        <div class="blog-area pt-120 pb-120">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-8 col-xl-8 col-lg-8">
                     <div class="blog-box-archive-wrapper">
                        <div class="ba-blog-box-archive mb-40">
                           <div class="image">
                              <a href="blog-details.php">
                                 <img src="assets/img/blog/blog-1.jpg" alt="">
                              </a>
                           </div>
                           <div class="content">
                              <div class="ba-blog-box-archive-meta pb-25">
                                 <a href="blog.php" class="item-1"><i class="fas fa-user"></i> <span>Endith Smith</span></a>
                                 <a href="blog-details.php" class="item-2"><i class="fas fa-calendar-alt"></i> <span>Aug 1, 2022</span></a>
                              </div>
                              <h3 class="ba-blog-box-archive-title"><a href="blog-details.php">Broadband Connection Needs To Everyone Life
                                 How to Build Your Broadband</a></h3>
                              <p>When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or minimizing the distractions of the draft copy. Second, use lorem ipsum if you think the placeholder text will be too distracting. For specific projects, a collaboration between copywriters and designers may be best, however, like KarecGran When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or</p>
                              <a href="blog-details.php" class="ba-submit-btn">Read More</a>
                           </div>
                        </div>
                        <div class="ba-blog-box-archive mb-40">
                           <div class="image">
                              <a href="blog-details.php">
                                 <img src="assets/img/blog/blog-2.jpg" alt="">
                              </a>
                           </div>
                           <div class="content">
                              <div class="ba-blog-box-archive-meta pb-25">
                                 <a href="blog.php" class="item-1"><i class="fas fa-user"></i> <span>Endith Smith</span></a>
                                 <a href="blog.php" class="item-2"><i class="fas fa-calendar-alt"></i> <span>Aug 1, 2022</span></a>
                              </div>
                              <h3 class="ba-blog-box-archive-title"><a href="blog-details.php">This Is How Broadband Will Look Like In 10 Years Time.</a></h3>
                              <p>When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or minimizing the distractions of the draft copy. Second, use lorem ipsum if you think the placeholder text will be too distracting. For specific projects, a collaboration between copywriters and designers may be best, however, like KarecGran When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or</p>
                              <a href="blog-details.php" class="ba-submit-btn">Read More</a>
                           </div>
                        </div>
                        <div class="ba-blog-box-archive mb-40">
                           <div class="image">
                              <a href="blog-details.php">
                                 <img src="assets/img/blog/blog-3.jpg" alt="">
                              </a>
                           </div>
                           <div class="content">
                              <div class="ba-blog-box-archive-meta pb-25">
                                 <a href="blog.php" class="item-1"><i class="fas fa-user"></i> <span>John Doe</span></a>
                                 <a href="blog.php" class="item-2"><i class="fas fa-calendar-alt"></i> <span>Feb 1, 2022</span></a>
                              </div>
                              <h3 class="ba-blog-box-archive-title"><a href="blog-details.php">How To Have A Fantastic Broadband With Minimal Spending.</a></h3>
                              <p>When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or minimizing the distractions of the draft copy. Second, use lorem ipsum if you think the placeholder text will be too distracting. For specific projects, a collaboration between copywriters and designers may be best, however, like KarecGran When to Use Lorem Ipsum generally, lorem ipsum is best suited to keeping templates from looking bare or</p>
                              <a href="blog-details.php" class="ba-submit-btn">Read More</a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xxl-4 col-xl-4 col-lg-4">
                     <div class="ba-blog-sidebar-widget-wrapper pl-50">
                        <div class="ba-blog-widget mb-50">
                           <div class="ba-blog-search-form">
                              <form action="#" method="post">
                                 <input type="search" placeholder="Search">
                                 <button type="submit"><i class="fal fa-search"></i></button>
                              </form>
                           </div>
                        </div>
                        <div class="ba-blog-widget mb-50">
                           <h4 class="ba-blog-widget-title">Categories</h4>
                           <div class="ba-blog-widget-list">
                              <ul>
                                 <li><a href="blog.php">Broadband <span class="count">(09)</span></a></li>
                                 <li><a href="blog.php">TV & Streaming <span class="count">(10)</span></a></li>
                                 <li><a href="blog.php">Satellite TV <span class="count">(45)</span></a></li>
                                 <li><a href="blog.php">Home Phone <span class="count">(19)</span></a></li>
                                 <li><a href="blog.php">Home Security <span class="count">(10)</span></a></li>
                                 <li><a href="blog.php">Internet (30) <span class="count">(45)</span></a></li>
                                 <li><a href="blog.php">Reportage <span class="count">(19)</span></a></li>
                              </ul>
                           </div>
                        </div>
                        <div class="ba-blog-widget mb-50">
                           <h4 class="ba-blog-widget-title">Latest Post</h4>
                           <div class="ba-blog-widget-post-wrapper">
                              <div class="ba-blog-widget-post fix mb-30">
                                 <div class="image">
                                    <a href="blog-details.php"><img src="assets/img/widgets/blog-sm-1.png" alt=""></a>
                                 </div>
                                 <div class="content pt-10">
                                    <h4 class="title">
                                       <a href="blog-details.php">This Place Really Place For Awesome Moment</a>
                                    </h4>
                                    <div class="date-meta">
                                       <i class="fal fa-calendar"></i> <span>July 24, 2022</span>
                                    </div>
                                 </div>
                              </div>
                              <div class="ba-blog-widget-post fix mb-30">
                                 <div class="image">
                                    <a href="blog-details.php"><img src="assets/img/widgets/blog-sm-2.png" alt=""></a>
                                 </div>
                                 <div class="content pt-10">
                                    <h4 class="title">
                                       <a href="blog-details.php">When Two Wheels Better Thannt</a>
                                    </h4>
                                    <div class="date-meta">
                                       <i class="fal fa-calendar"></i> <span>July 21, 2022</span>
                                    </div>
                                 </div>
                              </div>
                              <div class="ba-blog-widget-post fix mb-30">
                                 <div class="image">
                                    <a href="blog-details.php"><img src="assets/img/widgets/blog-sm-3.png" alt=""></a>
                                 </div>
                                 <div class="content pt-10">
                                    <h4 class="title">
                                       <a href="blog-details.php">Put Yourself In Our Awesome Customers</a>
                                    </h4>
                                    <div class="date-meta">
                                       <i class="fal fa-calendar"></i> <span>July 21, 2022</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="ba-blog-widget mb-50">
                           <h4 class="ba-blog-widget-title">Latest Post</h4>
                           <div class="tagcloud">
                              <a href="blog.php">Internet</a>
                              <a href="blog.php">Mobile</a>
                              <a href="blog.php">Online</a>
                              <a href="blog.php">Tv Box</a>
                              <a href="blog.php">Movie</a>
                              <a href="blog.php">Sports</a>
                              <a href="blog.php">Android</a>
                              <a href="blog.php">Iphone</a>
                              <a href="blog.php">Business</a>
                              <a href="blog.php">Finance</a>
                           </div>
                        </div>
                        <div class="ba-blog-widget mb-50">
                           <h4 class="ba-blog-widget-title">Newsletter</h4>
                           <div class="ba-blog-widget-subscribe-form">
                              <form action="#">
                                 <input type="text" placeholder="Newsletter">
                                 <button type="submit"><i class="fal fa-envelope"></i></button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </div>
        <!-- blog area end -->
      </main>
      <!-- footer area start -->
      <footer class="ba-footer-area ba-footer-overlay footer-1 bg-default" data-background="assets/img/bg/footer.jpg">
         <div class="ba-footer-cta">
            <div class="container">
               <div class="ba-footer-cta-border-bottom  pt-90 pb-80">
                  <div class="row align-items-center">
                     <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 pb-30 pb-md-0">
                        <h5 class="ba-footer-cta-title white-text">Want to contact with us?</h5>
                     </div>
                     <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                        <div class="text-md-end">
                           <a href="contact.php" class="ba-submit-btn">Contact Us</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="ba-footer-main-wrapper">
            <div class="container">
               <div class="ba-footer-cta-border-bottom pt-100 pb-100">
                  <div class="row">
                     <div class="col-xxl-3 col-xl-3 col-lg-5 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <div class="ba-footer-logo pb-45">
                              <a href="index.php"><img src="assets/img/logo/logo-white.png" alt=""></a>
                           </div>
                           <div class="ba-footer-content">
                              <p class="white-text">Feugiat a ligula rutrum luctus primis ultrice nteger congue magna at pretium purus a pretium ligula rutrum.</p>
                              <div class="ba-footer-contact-list pb-25">
                                 <span class="call white-text">Call us at 1-877-632-6789 or</span>
                                 <h6 class="title white-text">request An <a href="contact.php">Appointment Online.</a></h6>
                              </div>
                              <div class="ba-footer-social-list">
                                 <a href="#"><i class="fab fa-facebook-f"></i></a>
                                 <a href="#"><i class="fab fa-twitter"></i></a>
                                 <a href="#"><i class="fab fa-instagram"></i></a>
                                 <a href="#"><i class="fab fa-linkedin-in"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <h3 class="ba-footer-widget-title">Services</h3>
                           <ul>
                              <li><a href="index.php">Main Home</a></li>
                              <li><a href="about.php">About us</a></li>
                              <li><a href="blog.php">Blog</a></li>
                              <li><a href="contact.php">Contact Us</a></li>
                              <li><a href="service-details.php">Parking Lots</a></li>
                              <li><a href="service-details.php">Seal Coating</a></li>
                              <li><a href="pricing.php">Pricing</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <h3 class="ba-footer-widget-title">Instagrame Follow</h3>
                           <div class="ba-footer-widget-instagram-wrapper pt-10">
                              <ul>
                                 <li><a href="#"><img src="assets/img/footer/instagram-1.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-2.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-3.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-4.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-5.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-6.jpg" alt=""></a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget pr-50">
                           <h3 class="ba-footer-widget-title">Working Hours</h3>
                           <div class="ba-footer-widget-working-hours-list">
                              <ul>
                                 <li>
                                    <span class="label">Monday</span>
                                    <span class="value">10:00 – 11:00</span>
                                 </li>
                                 <li>
                                    <span class="label">Tusday</span>
                                    <span class="value">11:00 – 11:40</span>
                                 </li>
                                 <li>
                                    <span class="label">Wedesday</span>
                                    <span class="value">8:00 – 9:40</span>
                                 </li>
                                 <li>
                                    <span class="label">Thursday</span>
                                    <span class="value">7:50 – 8:40</span>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="ba-footer-copyright-wrapper pt-30 pb-30">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                     <p class="ba-footer-copyright-text white-text">Copyright 2022 Al Right Reserved</p>
                  </div>
                  <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                     <div class="ba-footer-copyright-list">
                        <ul>
                           <li><a href="index.php">Home</a></li>
                           <li><a href="about.php">About</a></li>
                           <li><a href="service.php">Service</a></li>
                           <li><a href="contact.php">Contact</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- footer area end --> 

      <!-- back to top start -->
      <div class="progress-wrap">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>
      <!-- back to top end -->
      

      <!-- JS here -->
      <script src="assets/js/jquery-3.6.0.min.js"></script>
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/meanmenu.js"></script>
      <script src="assets/js/swiper-bundle.min.js"></script>
      <script src="assets/js/magnific-popup.min.js"></script>
      <script src="assets/js/jquery-ui-slider-range.js"></script>
      <script src="assets/js/appair.min.js"></script>
      <script src="assets/js/odometer.min.js"></script>
      <script src="assets/js/backToTop.js"></script>
      <script src="assets/js/nice-select.min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/imagesloaded.pkgd.min.js"></script>
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/main.js"></script>
   </body>

</html>
