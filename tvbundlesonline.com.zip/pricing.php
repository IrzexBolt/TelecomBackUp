<!doctype html>
<html class="no-js" lang="zxx">
   
<head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Nafiab - Broadband & Internet HTML Template</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Place favicon.ico in the root directory -->
      <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
      <!-- CSS here -->
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/meanmenu.css">
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <link rel="stylesheet" href="assets/css/cursor.css">
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/jarallex.css">
      <link rel="stylesheet" href="assets/css/swiper-bundle.css">
      <link rel="stylesheet" href="assets/css/backToTop.css">
      <link rel="stylesheet" href="assets/css/flaticon.css">
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <link rel="stylesheet" href="assets/css/odometer-theme-default.css">
      <link rel="stylesheet" href="assets/css/nice-select.css">
      <link rel="stylesheet" href="assets/css/fontAwesome5Pro.css">
      <link rel="stylesheet" href="assets/css/default.css">
      <link rel="stylesheet" href="assets/css/main.css">
   </head>
   <body>

      <!-- header area start -->
         <header class="header-area header-1">
            <div class="ba-header-top-area bg-theme">
               <div class="container">
                  <div class="ba-header-top-content">
                     <div class="row">
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                           <a href="https://goo.gl/maps/qo6NG3ZXbN6bbev69" class="ba-header-top-list">
                              <i class="fal fa-location"></i>
                              <span>1901 Thornridge Cir. Shiloh, Hawaii 81063</span>
                           </a>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                           <div class="text-center text-md-end ba-header-top-right">
                              <a href="tel:98(000)-96302" class="ba-header-top-list">
                                 <i class="fal fa-phone-alt"></i>
                                 <span>+98(000)-96302</span>
                              </a>
                              <a href="mailto:info@tvbundlesonline.com" class="ba-header-top-list">
                                 <i class="fal fa-envelope"></i>
                                 <span>info@tvbundlesonline.com</span>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="ba-header-nav-area">
               <div class="container style-2">
                  <div class="ba-header-nav-inner">
                     <div class="row align-items-center">
                        <div class="col-xxl-4 col-6 col-xl-4 col-lg-3 col-md-6">
                           <div class="ba-header-logo">
                              <a href="index.php">
                                 <img src="assets/img/logo/logo.png" alt="">
                              </a>
                           </div>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-9 d-none d-lg-block">
                           <div class="ba-header-nav-wrapper text-end">
                              <nav class="ba-header-nav-menu" id="mobile-menu">
                                 <ul> 
                                    <li>
                                       <a href="index.php">Home</a>
                                       <ul class="submenu">
                                          <li><a href="index.php">Home 01</a></li>
                                          <li><a href="index-2.php">Home 02</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="about.php">About</a>
                                    </li>
                                    <li>
                                       <a href="blog.php">Blog</a>
                                       <ul class="submenu">
                                          <li><a href="blog.php">Blog</a></li>
                                          <li><a href="blog-details.php">Blog Details</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="#0">Pages</a>
                                       <ul class="submenu">
                                          <li><a href="error.php">Error</a></li>
                                          <li><a href="faq.php">Faq</a></li>
                                          <li><a href="pricing.php">Pricing</a></li>
                                          <li><a href="service.php">Service</a></li>
                                          <li><a href="service-details.php">Service Details</a></li>
                                          <li><a href="team.php">Team</a></li>
                                          <li><a href="team-details.php">Team Details</a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="contact.php">Contact</a>
                                    </li>
                                 </ul>
                              </nav>
                              <div class="ba-header-right-actions pl-50">
                                 <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                                 <a class="ba-header-right-link" href="contact.php"><i class="fal fa-user"></i></a>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6 col-6 d-lg-none">
                           <div class="ba-header-right-actions text-end d-block">
                              <div class="d-none d-md-inline-block">
                                 <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                                 <a class="ba-header-right-link" href="contact.php"><i class="fal fa-user"></i></a>
                              </div>
                              <a class="ba-header-right-link ba-header-sidebar-action" href="#0"><i class="fal fa-bars"></i></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
      <!-- header area end -->
      <!-- header search start -->
      <div class="ba-search-popup">
         <div class="ba-color-layer"></div>
         <div class="ba-search-popup-inner">
            <form action="#">
               <input type="text" placeholder="Search here..." name="search" id="search-input">
               <button type="submit"><i class="fal fa-search"></i></button>
            </form>
         </div>
      </div>
      <!-- header search end -->
      <div class="overlay"></div>
      <!-- sidebar area start -->
      <div class="ba-sidebar-area">
         <div class="ba-sidebar-inner">
            <div class="ba-sidebar-top">
               <nav>
                  <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                  <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab" data-bs-target="#sidebar-nav-1-control" type="button" role="tab" aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                  <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab" data-bs-target="#sidebar-nav-2-control" type="button" role="tab" aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                  </div>
               </nav>
            </div>
            <div class="ba-sidebar-content">
               <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-1">
                     <div class="ba-sidebar-nav-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="ba-sidebar-navigation-main">
                           <div class="mobile-menu"></div>
                        </div>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel" aria-labelledby="ba-sidebar-nav-2">
                     <div class="ba-sidebar-info-content">
                        <div class="ba-sidebar-logo-action-wrapper">
                           <div class="row align-items-center">
                              <div class="col-md-6 col-7">
                                 <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                 </div>
                              </div>
                              <div class="col-md-6 col-5">
                                 <div class="action">
                                    <div class="text-end">
                                       <button class="ba-header-sidebar-action-close"><i class="fal fa-times"></i></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <p>We must explain to you how all seds this mistakens idea off denouncing pleasures and praising pain was born and I will give you a completed accounts of the system and expound.</p>
                        <button type="submit" class="ba-submit-btn">Contact Us</button>
                        <div class="ba-header-right-actions text-end mt-35">
                           <button class="ba-header-right-link ba-header-search-btn"><i class="fal fa-search"></i></button>
                              <a class="ba-header-right-link" href="index.php"><i class="fal fa-user"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- sidebar area end -->
      <main>
        <!-- breadcrumb area start -->
        <div class="ba-breadcrumb-area bg-default ba-breadcrumb-reverce-space has-breadcrumb-overlay " data-background="assets/img/bg/breadcrumb.jpg">
            <div class="container style-2">
                <div class="ba-breadcrumb-inner-wrapper pl-40 pt-140 pb-115 pr-40 p-rel">
                  <h1 class="ba-breadcrumb-title">Pricing</h1>
                  <div class="ba-breadcrumb-navs ba-breadcrumb-navs-has-pos">
                     <a href="index.php">Home</a>
                     <span class="current">Pricing</span>
                  </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb area end -->
        <!-- pricing area start -->
        <div class="pricing-area pt-110 pb-120">
            <div class="container">
                <div class="row pb-60">
                    <div class="col-xxl-12">
                       <div class="ba-section-title-wrapper text-center">
                          <h3 class="ba-section-title ba-has-wrapped-br">Choose Your Internet<br> Pack By Speed</h3>
                       </div>
                    </div>
                 </div>
                 <div class="row pb-70">
                    <div class="col-xxl-12">
                        <div class="text-center">
                           <div class="d-inline-block">
                              <div class="ba-pricing-box-tab">
                                 <nav>
                                     <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                       <button class="nav-link active" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly" aria-selected="true">Monthly</button>
                                       <button class="nav-link" id="yearly-tab" data-bs-toggle="tab" data-bs-target="#yearly" type="button" role="tab" aria-controls="yearly" aria-selected="false">Profile</button>
                                     </div>
                                 </nav>
                             </div>
                           </div>
                        </div>
                    </div>
                 </div>
                 <div class="tab-content" id="nav-pricing-tab">
                     <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                        <div class="row">
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".1s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">Broadband & WIFI</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$120<span>/6 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default active wow fadeInUp" data-wow-delay=".2s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">TV Combo Bundle</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$30<span>/4 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn white-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".3s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">Internet For Corporate</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$20<span>/2 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="tab-pane fade" id="yearly" role="tabpanel" aria-labelledby="yearly-tab">
                        <div class="row">
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".1s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">Broadband & WIFI</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$599<span>/6 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default active wow fadeInUp" data-wow-delay=".2s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">TV Combo Bundle</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$389<span>/4 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn white-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                           <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                              <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".3s" data-background="assets/img/bg/pricing-bg.jpg">
                                 <h4 class="ba-pricing-box-title">Internet For Corporate</h4>
                                 <h5 class="ba-pricing-box-count pb-20">$278<span>/2 Month</span></h5>
                                 <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div>
                                 <div class="ba-pricing-box-list-wrap">
                                    <ul class="pb-35">
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                                       <li class="active"><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                    </ul>
                                    <a href="contact.php" class="ba-submit-btn">Discover App</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
        </div>
        <!-- pricing area end -->
         <!-- movie area start -->
         <section class="movie-area bg-default pb-100 pt-100" data-background="assets/img/bg/news-1.jpg">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-6 col-xl-6 col-lg-6 pb-50 pb-lg-0">
                     <div class="ba-movie-content pr-185">
                        <h4 class="ba-movie-title wow fadeInUp" data-wow-delay=".1s">Enjoy Sports Movies,<br> TV Shows & More</h4>
                        <p class="wow fadeInUp"  data-wow-delay=".2s">Nisi utm aliquip sed tempor duis aute lorem ipsum dolor sitye ametautys adipisicing elit sed dolor eiusmod </p>
                        <div class="ba-movie-price-service-duration-wrap pb-45 wow fadeInUp" data-wow-delay=".3s">
                           <h5 class="ba-movie-price">30$/ <span>1 Month</span></h5>
                           <div class="ba-movie-service-duration">
                                 <i class="fal fa-router"></i>
                                 <span>1month WIFi Free</span>
                           </div>
                        </div>
                        <a href="contact.php" class="ba-submit-btn wow fadeInUp"  data-wow-delay=".4s">Cheak Availibilty</a>
                     </div>
                  </div>
                  <div class="col-xxl-6 col-xl-6 col-lg-6">
                     <div class="ba-movie-right-img text-lg-end">
                        <img src="assets/img/movie/movie-1.png" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- movie area end -->
         <!-- pricing area start -->
        <div class="pricing-area pt-110 pb-120">
         <div class="container">
             <div class="row pb-60">
                 <div class="col-xxl-12">
                    <div class="ba-section-title-wrapper text-center">
                       <h3 class="ba-section-title ba-has-wrapped-br">Choose Your Internet<br> Pack By Speed</h3>
                    </div>
                 </div>
              </div>
              <div class="row">
               <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                  <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".1s" data-background="assets/img/bg/pricing-bg-1.png">
                     <h4 class="ba-pricing-box-title">Broadband & WIFI</h4>
                     <h5 class="ba-pricing-box-count pb-20">$599<span>/6 Month</span></h5>
                     <div class="ba-pricing-box-icons-wrap pb-50">
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-wifi"></i>
                        </div>
                        <div class="ba-pricing-box-icon active">
                           <i class="fal fa-broadcast-tower"></i>
                        </div>
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-house"></i>
                        </div>
                     </div>
                     <div class="ba-pricing-box-list-wrap">
                        <ul class="pb-35">
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                        </ul>
                        <a href="contact.php" class="ba-submit-btn">Get Started</a>
                     </div>
                  </div>
               </div>
               <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                  <div class="ba-pricing-box text-center bg-default active wow fadeInUp" data-wow-delay=".2s" data-background="assets/img/bg/pricing-bg-2.png">
                     <h4 class="ba-pricing-box-title">TV Combo Bundle</h4>
                     <h5 class="ba-pricing-box-count pb-20">$389<span>/4 Month</span></h5>
                     <div class="ba-pricing-box-icons-wrap pb-50">
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-wifi"></i>
                        </div>
                        <div class="ba-pricing-box-icon active">
                           <i class="fal fa-broadcast-tower"></i>
                        </div>
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-house"></i>
                        </div>
                     </div>
                     <div class="ba-pricing-box-list-wrap">
                        <ul class="pb-35">
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                        </ul>
                        <a href="contact.php" class="ba-submit-btn white-btn">Get Started</a>
                     </div>
                  </div>
               </div>
               <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                  <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".3s" data-background="assets/img/bg/pricing-bg-3.png">
                     <h4 class="ba-pricing-box-title">Internet For Corporate</h4>
                     <h5 class="ba-pricing-box-count pb-20">$278<span>/2 Month</span></h5>
                     <div class="ba-pricing-box-icons-wrap pb-50">
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-wifi"></i>
                        </div>
                        <div class="ba-pricing-box-icon active">
                           <i class="fal fa-broadcast-tower"></i>
                        </div>
                        <div class="ba-pricing-box-icon">
                           <i class="fal fa-house"></i>
                        </div>
                     </div>
                     <div class="ba-pricing-box-list-wrap">
                        <ul class="pb-35">
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Home Broadband</span></li>
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite TV</span></li>
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Cell phone connection</span></li>
                           <li class="active"><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                           <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                        </ul>
                        <a href="contact.php" class="ba-submit-btn">Get Started</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
     </div>
     <!-- pricing area end -->
        
      </main>
      <!-- footer area start -->
      <footer class="ba-footer-area ba-footer-overlay footer-1 bg-default" data-background="assets/img/bg/footer.jpg">
         <div class="ba-footer-cta">
            <div class="container">
               <div class="ba-footer-cta-border-bottom  pt-90 pb-80">
                  <div class="row align-items-center">
                     <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 pb-30 pb-md-0">
                        <h5 class="ba-footer-cta-title white-text">Want to contact with us?</h5>
                     </div>
                     <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                        <div class="text-md-end">
                           <a href="contact.php" class="ba-submit-btn">Contact Us</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="ba-footer-main-wrapper">
            <div class="container">
               <div class="ba-footer-cta-border-bottom pt-100 pb-100">
                  <div class="row">
                     <div class="col-xxl-3 col-xl-3 col-lg-5 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <div class="ba-footer-logo pb-45">
                              <a href="index.php"><img src="assets/img/logo/logo-white.png" alt=""></a>
                           </div>
                           <div class="ba-footer-content">
                              <p class="white-text">Feugiat a ligula rutrum luctus primis ultrice nteger congue magna at pretium purus a pretium ligula rutrum.</p>
                              <div class="ba-footer-contact-list pb-25">
                                 <span class="call white-text">Call us at 1-877-632-6789 or</span>
                                 <h6 class="title white-text">request An <a href="contact.php">Appointment Online.</a></h6>
                              </div>
                              <div class="ba-footer-social-list">
                                 <a href="#"><i class="fab fa-facebook-f"></i></a>
                                 <a href="#"><i class="fab fa-twitter"></i></a>
                                 <a href="#"><i class="fab fa-instagram"></i></a>
                                 <a href="#"><i class="fab fa-linkedin-in"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <h3 class="ba-footer-widget-title">Services</h3>
                           <ul>
                              <li><a href="index.php">Main Home</a></li>
                              <li><a href="about.php">About us</a></li>
                              <li><a href="blog.php">Blog</a></li>
                              <li><a href="contact.php">Contact Us</a></li>
                              <li><a href="service-details.php">Parking Lots</a></li>
                              <li><a href="service-details.php">Seal Coating</a></li>
                              <li><a href="pricing.php">Pricing</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget">
                           <h3 class="ba-footer-widget-title">Instagrame Follow</h3>
                           <div class="ba-footer-widget-instagram-wrapper pt-10">
                              <ul>
                                 <li><a href="#"><img src="assets/img/footer/instagram-1.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-2.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-3.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-4.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-5.jpg" alt=""></a></li>
                                 <li><a href="#"><img src="assets/img/footer/instagram-6.jpg" alt=""></a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-35 mb-xl-0">
                        <div class="ba-footer-widget pr-50">
                           <h3 class="ba-footer-widget-title">Working Hours</h3>
                           <div class="ba-footer-widget-working-hours-list">
                              <ul>
                                 <li>
                                    <span class="label">Monday</span>
                                    <span class="value">10:00 – 11:00</span>
                                 </li>
                                 <li>
                                    <span class="label">Tusday</span>
                                    <span class="value">11:00 – 11:40</span>
                                 </li>
                                 <li>
                                    <span class="label">Wedesday</span>
                                    <span class="value">8:00 – 9:40</span>
                                 </li>
                                 <li>
                                    <span class="label">Thursday</span>
                                    <span class="value">7:50 – 8:40</span>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="ba-footer-copyright-wrapper pt-30 pb-30">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                     <p class="ba-footer-copyright-text white-text">Copyright 2022 Al Right Reserved</p>
                  </div>
                  <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                     <div class="ba-footer-copyright-list">
                        <ul>
                           <li><a href="index.php">Home</a></li>
                           <li><a href="about.php">About</a></li>
                           <li><a href="service.php">Service</a></li>
                           <li><a href="contact.php">Contact</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- footer area end --> 

      <!-- back to top start -->
      <div class="progress-wrap">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>
      <!-- back to top end -->
      

      <!-- JS here -->
      <script src="assets/js/jquery-3.6.0.min.js"></script>
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/meanmenu.js"></script>
      <script src="assets/js/swiper-bundle.min.js"></script>
      <script src="assets/js/magnific-popup.min.js"></script>
      <script src="assets/js/jquery-ui-slider-range.js"></script>
      <script src="assets/js/appair.min.js"></script>
      <script src="assets/js/odometer.min.js"></script>
      <script src="assets/js/backToTop.js"></script>
      <script src="assets/js/nice-select.min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/imagesloaded.pkgd.min.js"></script>
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/main.js"></script>
   </body>

</html>
