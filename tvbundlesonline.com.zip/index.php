<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internet and TV Bundles USA- TV Bundles Online</title>
    <!-- <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon"> -->


    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/cursor.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/jarallex.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.css">
    <link rel="stylesheet" href="assets/css/backToTop.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/odometer-theme-default.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/fontAwesome5Pro.css">
    <link rel="stylesheet" href="assets/css/default.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
    <div class="header-banner-bg">
        <div class="container">
            <!------- HEADER TOP START ------->
            <div class="header-top">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <!-- <span class="header-top-address">
                            <i class="fal fa-map-marker-alt"></i> 1901 Thornridge Cir. Shiloh, Hawaii 81063
                        </span> -->
                    </div>

                    <div class="col-md-6">
                        <div class="header-top-contact">
                            <span class="header-top-conatact__phone">
                                <a href="tel:98(000)-96302"><i class="fal fa-phone-alt"></i> +18662616841</a>
                            </span>

                            <span class="header-top-conatact__email">
                                <a href="mailto:info@tvbundlesonline.com"><i class="fal fa-envelope"></i> info@tvbundlesonline.com</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <!------- HEADER TOP END ------->

            <header class="header-area header-1">

                <div class="ba-header-nav-area">
                    <div class="style-2">
                        <div class="ba-header-nav-inner header-bottom">
                            <div class="row align-items-center">

                                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-6">
                                    <div class="ba-header-logo">
                                        <a href="index.php">
                                            <img src="assets/img/logo/logo-3.png" alt="logo">
                                        </a>
                                    </div>
                                </div>

                                <div class="col-xxl-9 col-xl-9 col-lg-9 d-none d-lg-block">
                                    <div class="ba-header-nav-wrapper text-end">
                                        <nav class="ba-header-nav-menu header-bottom__nav" id="mobile-menu">
                                            <ul>
                                                <li>
                                                    <a href="index.php">Home</a>
                                                    <!-- <ul class="submenu index-1-submenu">
                                                        <li><a href="index.php">Home 01</a></li>
                                                        <li><a href="index-2.php">Home 02</a></li>
                                                    </ul> -->
                                                </li>
                                                <!-- <li>
                                                    <a href="about.php">About</a>
                                                </li>
                                                <li>
                                                    <a href="blog.php">Blog</a>
                                                    <ul class="submenu index-1-submenu">
                                                        <li><a href="blog.php">Blog</a></li>
                                                        <li><a href="blog-details.php">Blog Details</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="#0">Pages</a>
                                                    <ul class="submenu index-1-submenu">
                                                        <li><a href="error.php">Error</a></li>
                                                        <li><a href="faq.php">Faq</a></li>
                                                        <li><a href="pricing.php">Pricing</a></li>
                                                        <li><a href="service.php">Service</a></li>
                                                        <li><a href="service-details.php">Service Details</a></li>
                                                        <li><a href="team.php">Team</a></li>
                                                        <li><a href="team-details.php">Team Details</a></li>
                                                    </ul>
                                                </li> -->
                                                <li>
                                                    <a href="privacy-policy.php">Privacy Policy</a>
                                                </li>
                                                <li>
                                                    <a href="contact.php">Contact</a>
                                                </li>
                                            </ul>
                                        </nav>
                                        <div class="ba-header-right-actions index-1-header-btns pl-50">
                                            <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                <i class="fal fa-search"></i>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                <i class="fal fa-shopping-bag"></i>

                                                <span class="index-1-cart-number-popup">
                                                    <span>0</span>
                                                </span>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-6 d-lg-none">
                                    <div class="ba-header-right-actions index-1-header-btns text-end d-block">
                                        <div class="d-none d-md-inline-block">
                                            <button class="ba-header-right-link btn-index-1 ba-header-search-btn">
                                                <i class="fal fa-search"></i>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1 btn-index-1--cart">
                                                <i class="fal fa-shopping-bag"></i>

                                                <span class="index-1-cart-number-popup">
                                                    <span>0</span>
                                                </span>
                                            </button>

                                            <button class="ba-header-right-link btn-index-1"><i class="fal fa-user"></i>
                                            </button>
                                        </div>

                                        <button class="ba-header-right-link btn-index-1 ba-header-sidebar-action">
                                            <i class="fal fa-bars"></i>
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- header area end -->

            <!-- header search start -->
            <div class="ba-search-popup">
                <div class="ba-color-layer"></div>
                <div class="ba-search-popup-inner">
                    <form action="#">
                        <input type="text" placeholder="Search here..." name="search" id="search-input">
                        <button type="submit"><i class="fal fa-search"></i></button>
                    </form>
                </div>
            </div>
            <!-- header search end -->

            <div class="overlay"></div>

            <div class="ba-sidebar-area">
                <div class="ba-sidebar-inner">
                    <div class="ba-sidebar-top">
                        <nav>
                            <div class="nav nav-tabs" id="ba-sidebar-nav" role="tablist">
                                <button class="nav-link active" id="ba-sidebar-nav-1" data-bs-toggle="tab"
                                    data-bs-target="#sidebar-nav-1-control" type="button" role="tab"
                                    aria-controls="sidebar-nav-1-control" aria-selected="true">Menu</button>
                                <button class="nav-link" id="ba-sidebar-nav-2" data-bs-toggle="tab"
                                    data-bs-target="#sidebar-nav-2-control" type="button" role="tab"
                                    aria-controls="sidebar-nav-2-control" aria-selected="false">Info</button>
                            </div>
                        </nav>
                    </div>
                    <div class="ba-sidebar-content">
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="sidebar-nav-1-control" role="tabpanel"
                                aria-labelledby="ba-sidebar-nav-1">
                                <div class="ba-sidebar-nav-content">
                                    <div class="ba-sidebar-logo-action-wrapper">
                                        <div class="row align-items-center">
                                            <div class="col-md-6 col-7">
                                                <div class="logo">
                                                    <a href="index.php"><img src="assets/img/logo/logo.png"
                                                            alt="logo"></a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-5">
                                                <div class="action">
                                                    <div class="text-end">
                                                        <button class="ba-header-sidebar-action-close"><i
                                                                class="fal fa-times"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ba-sidebar-navigation-main">
                                        <div class="mobile-menu"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="sidebar-nav-2-control" role="tabpanel"
                                aria-labelledby="ba-sidebar-nav-2">
                                <div class="ba-sidebar-info-content">
                                    <div class="ba-sidebar-logo-action-wrapper">
                                        <div class="row align-items-center">
                                            <div class="col-md-6 col-7">
                                                <div class="logo">
                                                    <a href="index.php"><img src="assets/img/logo/logo.png"
                                                            alt="logo"></a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-5">
                                                <div class="action">
                                                    <div class="text-end">
                                                        <button class="ba-header-sidebar-action-close"><i
                                                                class="fal fa-times"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p>We must explain to you how all seds this mistakens idea off denouncing pleasures
                                        and praising pain was born and I will give you a completed accounts of the
                                        system and expound.</p>
                                    <button type="submit" class="ba-submit-btn">Contact Us</button>
                                    <div class="ba-header-right-actions text-end mt-35">
                                        <button class="ba-header-right-link ba-header-search-btn"><i
                                                class="fal fa-search"></i></button>
                                        <a class="ba-header-right-link" href="index.php"><i
                                                class="fal fa-user"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!----------------- BANNER SECTION STARTS ----------------->
            <section id="banner-section">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-8">
                            <h1 class="ba-hero-title index-1-hero-title">Your Only Connectivity Hub</h1>
                            <h4 class="hero__title">

                                Enjoy Non-Stop TV Streaming & Internet
                            </h4>

                            <p class="hero-txt">Established 10 years back by telecom industry experts, the internet
                                bundle hub has transformed the ways of connectivity by building a robust and
                                uninterrupted broadband and telecom network across the United States.</p>

                            <a href="tel:+18662616841" class="ba-submit-btn">Contact Now</a>
                            <!-- <a href="#" class="ba-submit-btn">Contact Now</a> -->
                        </div>
                        <div class="col-xl-6 col-lg-8">
                            <div class="banner__img">
                                <img src="./assets/img/user/img-1.png" alt="">
                            </div>
                </div>
            </section>
            <!----------------- BANNER SECTION ENDS ----------------->

        </div>
    </div>

    <main>
        <!----------------- ABOUT SECTION STARTS ----------------->
        <section id="about-section" class="pt-120 pb-120 position-relative overflow-hidden">
            <span class="circle-animation dir-top-left">
                <img src="assets/img/vector/circle-vector.png" alt="circle">
            </span>
            <div class="container">
                <div class="row justify-content-center">
                    <!-- ABOUT LEFT CONTENT -->

                    <!-- Services Section Start -->
                    <div class="service-area">
                        <div class="container">

                            <div class="row">
                                <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xxl-0">
                                    <div class="ba-service-box-3 text-center">
                                        <div class="icon">
                                            <i class="fal fa-cctv"></i>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="service-details.php">Internet</a></h5>
                                            <p>We provide a broad range of internet speeds, including fiber-optic,
                                                satellite, and other as well, to meet different internet bandwidth
                                                requirements.</p>
                                            <!-- <a href="service-details.php" class="ba-service-box-3-link">Read More</a> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xxl-0">
                                    <div class="ba-service-box-3 text-center">
                                        <div class="icon">
                                            <i class="fal fa-tv-alt"></i>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="service-details.php">TV SERVICE</a></h5>
                                            <p>Whether connecting via Satellite or your existing Internet service, our
                                                TV packages have it all. Get the best of entertainment, sports & news
                                                with our services.</p>
                                            <!-- <a hreIf="service-details.php" class="ba-service-box-3-link">Read More</a> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xxl-0">
                                    <div class="ba-service-box-3 text-center">
                                        <div class="icon">
                                            <i class="fal fa-mobile"></i>
                                        </div>
                                        <div class="content">
                                            <h5 class="title"><a href="service-details.php">Home Security</a></h5>
                                            <p>We make your home secure! Protect your place with our leading home
                                                security experts, complete with 24/7 home monitoring.</p>
                                            <!-- <a href="service-details.php" class="ba-service-box-3-link">Read More</a> -->
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xxl-0">
             <div class="ba-service-box-3 text-center">
                <div class="icon">
                   <i class="fal fa-wifi"></i>
                </div> -->
                                <!-- <div class="content">
                   <h5 class="title"><a href="service-details.php">WIFI Internet</a></h5>
                   <p>It is a long established fact that a reader will be distracted by the readable content</p> -->
                                <!-- <a href="service-details.php" class="ba-service-box-3-link">Read More</a> -->
                                <!-- </div>
             </div> -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Services Section End -->

                <!-- ABOUT LEFT CONTENT -->

                <!-- ABOUT RIGHT CONTENT -->
                <div class="about-area-2 pt-120 pb-60">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xxl-6 col-xl-6">
                                <div class="ba-about-right-wrapper">
                                    <div class="ba-section-title-wrapper pb-25">
                                        <h5 class="ba-section-subtitle wow fadeInUp" data-wow-delay=".1s">About Us</h5>
                                        <h3 class="ba-section-title wow fadeInUp" data-wow-delay=".2s">Ready to Join the
                                            <br>Streaming Revolution</h3>

                                    </div>
                                    <div class="ba-about-right-content">
                                        <div class="text wow fadeInUp" data-wow-delay=".3s">
                                            <p>
                                                At Tv Bundles Online, we provide flawless streaming and uninterrupted tv
                                                and internet services. We have partnered with the top broadband,
                                                internet, and cable tv service providers in the country to provide our
                                                customers with 100% satisfaction rate. Our packages ensure consistent,
                                                high-speed internet, TV, and phone services for your home.
                                            </p>
                                            <!-- <p> <a href="contact.php">Available at checkout.</a>Watch thousands of awesome TV shows,<br> movies, and documentaries.</p> -->
                                        </div>
                                    </div>
                                    <div class="ba-about-right-list pr-95">
                                        <ul>
                                            <li>

                                            </li>
                                            <!-- <li class="wow fadeInUp" data-wow-delay=".4s">
                                             <div class="icon">
                                                <img src="assets/img/icons/icon-1.png" alt="">
                                             </div>
                                             <div class="content">
                                                <h4 class="title">Speed faster than a gig</h4>
                                                <p>Medixer Care will be administered through plan-based omizable incorporate partnership between family.</p>
                                             </div> -->
                                            </li>
                                            <!-- <li class="wow fadeInUp" data-wow-delay=".5s">
                                             <div class="icon">
                                                <img src="assets/img/icons/icon-2.png" alt="">
                                             </div>
                                             <div class="content">
                                                <h4 class="title">Protect your devices</h4>
                                                <p>Medixer Care will be administered through plan-based omizable incorporate partnership between family.</p>
                                             </div>
                                          </li> -->
                                        </ul>
                                    </div>
                                    <div class="ba-about-right-actions wow fadeInUp" data-wow-delay=".6s">
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-6 col-xl-6">
                                <div class="text-xl-end">
                                    <div class="ba-about-right-img-box-2 d-inline-block">
                                        <img src="assets/img/about/about-3.png" alt="">
                                        <!-- <div class="ba-about-right-count-box-2 has-pos">
                                          <p class="title"><span class="count">20</span> years<br> Experience</p>
                                       </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ABOUT RIGHT CONTENT -->
            </div>
            </div>
        </section>
        <!----------------- ABOUT SECTION ENDS ----------------->

        <div class="pricing-area">
            <div class="container">
                <div class="row ">
                    <div class="col-xxl-12">
                        <div class="ba-section-title-wrapper text-center">
                            <h3 class="ba-section-title choose ba-has-wrapped-br">Choose Your Plan</h3>

                            <p class="plan__para">
                                Our plan cards are designed to be intuitive and easy to understand. Each card starts
                                with a clear and affordable price point, and we highlight the key features and benefits
                                of each plan.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="row pb-40">
                    <div class="col-xxl-12">
                        <div class="text-center">
                            <div class="d-inline-block">
                                <div class="ba-pricing-box-tab">
                                    <!-- <nav>
                                     <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                       <button class="nav-link active" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly" aria-selected="true">Monthly</button>
                                       <button class="nav-link" id="yearly-tab" data-bs-toggle="tab" data-bs-target="#yearly" type="button" role="tab" aria-controls="yearly" aria-selected="false">Profile</button>
                                     </div>
                                 </nav> -->
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="nav-pricing-tab">
                    <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".1s"
                                    data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">PLAN 1</h4>
                                    <h5 class="ba-pricing-box-count pb-20">$24.99</h5>
                                    <h4 class="ba-pricing-box-title">
                                        Month
                                    </h4>
                                    <!-- <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div> -->
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>100+ HD Quality
                                                    Channels</span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Live TV
                                                    Streaming</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>DVR Storage</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>No Contracts</span></li>
                                            <!-- <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li> -->
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default active wow fadeInUp"
                                    data-wow-delay=".2s" data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">PLAN 2</h4>
                                    <h5 class="ba-pricing-box-count pb-20">$49.99</h5>
                                    <h4 class="ba-pricing-box-title">
                                        Month
                                    </h4>
                                    <!-- <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div> -->
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Download Speed
                                                    Up To 100 Mbps
                                                </span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>No Data Caps
                                                </span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Exceptional Wifi Coverage
                                                </span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>No Cancellation Fees

                                                </span></li>
                                            <!-- <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                       <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li> -->
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".3s"
                                    data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">PLAN 3
                                    </h4>
                                    <h5 class="ba-pricing-box-count pb-20">$55.00</h5>
                                    <h4 class="ba-pricing-box-title">
                                        Month
                                    </h4>
                                    <!-- <div class="ba-pricing-box-icons-wrap pb-50">
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-wifi"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon active">
                                       <i class="fal fa-broadcast-tower"></i>
                                    </div>
                                    <div class="ba-pricing-box-icon">
                                       <i class="fal fa-house"></i>
                                    </div>
                                 </div> -->
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Unlimited Local
                                                    Calling
                                                </span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite
                                                    TV</span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Hotspot Support
                                                </span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Call Forwarding
                                                    and Speed Dialing
                                                </span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Optional Long-Distance Calling

                                                </span></li>
                                            <!-- <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li> -->
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="yearly" role="tabpanel" aria-labelledby="yearly-tab">
                        <div class="row">
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".1s"
                                    data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">Broadband & WIFI</h4>
                                    <h5 class="ba-pricing-box-count pb-20">$599<span>/6 Month</span></h5>
                                    <div class="ba-pricing-box-icons-wrap pb-50">
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-wifi"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon active">
                                            <i class="fal fa-broadcast-tower"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-house"></i>
                                        </div>
                                    </div>
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Unlimited Local
                                                    Calling
                                                </span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite
                                                    TV</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span>
                                            </li>
                                            <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default active wow fadeInUp"
                                    data-wow-delay=".2s" data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">TV Combo Bundle</h4>
                                    <h5 class="ba-pricing-box-count pb-20">$389<span>/4 Month</span></h5>
                                    <div class="ba-pricing-box-icons-wrap pb-50">
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-wifi"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon active">
                                            <i class="fal fa-broadcast-tower"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-house"></i>
                                        </div>
                                    </div>
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Unlimited Local
                                                    Calling
                                                </span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite
                                                    TV</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Cell phone connection</span>
                                            </li>
                                            <li><i class="fal fa-check-circle"></i> <span>Home security</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn white-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                                <div class="ba-pricing-box text-center bg-default wow fadeInUp" data-wow-delay=".3s"
                                    data-background="assets/img/bg/pricing-bg.jpg">
                                    <h4 class="ba-pricing-box-title">PLAN 3</h4>
                                    <h5 class="ba-pricing-box-count pb-20">$278<span>/2 Month</span></h5>
                                    <div class="ba-pricing-box-icons-wrap pb-50">
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-wifi"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon active">
                                            <i class="fal fa-broadcast-tower"></i>
                                        </div>
                                        <div class="ba-pricing-box-icon">
                                            <i class="fal fa-house"></i>
                                        </div>
                                    </div>
                                    <div class="ba-pricing-box-list-wrap">
                                        <ul class="pb-35">
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Home
                                                    Broadband</span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Satellite
                                                    TV</span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Cell phone
                                                    connection</span></li>
                                            <li class="active"><i class="fal fa-check-circle"></i> <span>Home
                                                    security</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Single Device Uses</span></li>
                                            <li><i class="fal fa-check-circle"></i> <span>Random IP</span></li>
                                        </ul>
                                        <a href="tel:+18662616841" class="ba-submit-btn">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!----------------- PACKAGE SECTION STARTS ----------------->
        <!-- <section id="package-section" class="pt-120 pb-120 bg-default text-center"
            data-background="assets/img/bg/package.jpg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <h2 class="ba-section-title section-title">Choose Your Internet <br> Pack By Speed</h2>
                        <div class="package-section__btns">
                            <a href="#" class="custom-btn">What speed do I need?</a>
                            <a href="#" class="custom-btn">What is Internet speed?</a>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-xxl-11">
                        <div class="package-tabs">
                            <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-400-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-400" type="button" role="tab" aria-controls="pills-400"
                                        aria-selected="true">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">400</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-500-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-500" type="button" role="tab" aria-controls="pills-500"
                                        aria-selected="false">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">500</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-600-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-600" type="button" role="tab" aria-controls="pills-600"
                                        aria-selected="false">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">600</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-700-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-700" type="button" role="tab" aria-controls="pills-700"
                                        aria-selected="false">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">700</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-800-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-800" type="button" role="tab" aria-controls="pills-800"
                                        aria-selected="false">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">800</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-900-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-900" type="button" role="tab" aria-controls="pills-900"
                                        aria-selected="false">
                                        <img src="assets/img/icons/package-icon-2.svg" alt="network icon"
                                            class="package-nav-btn__icon">
                                        <span class="package-nav-btn__title">900</span>
                                        <span class="package-nav-btn__subtitle">Mbps</span>
                                    </button>
                                </li>
                            </ul>

                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-400" role="tabpanel"
                                    aria-labelledby="pills-400-tab">

                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">400 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>


                                </div>


                                <div class="tab-pane fade" id="pills-500" role="tabpanel"
                                    aria-labelledby="pills-500-tab">
                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">500 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="tab-pane fade" id="pills-600" role="tabpanel"
                                    aria-labelledby="pills-600-tab">
                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">600 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="pills-700" role="tabpanel"
                                    aria-labelledby="pills-700-tab">
                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">700 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="pills-800" role="tabpanel"
                                    aria-labelledby="pills-800-tab">
                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="pills-900" role="tabpanel"
                                    aria-labelledby="pills-900-tab">
                                    <div class="package-details">
                                        <div class="row justify-content-between">
                                            <div class="col-xl-6 col-lg-7">
                                                <h5 class="package-details__title">Manage Current Plan</h5>
                                                <p class="package-details__txt">Lorem ipsum dolor sit amet
                                                    consectetur
                                                    adipisicing
                                                    elit.
                                                    Quidem fugit pariatur libero itaque, nisi minus doloremque sed
                                                    iusto
                                                    a
                                                    earum?
                                                </p>

                                                <div class="package-details__features-container d-flex">
                                                    <div class="single-pack-feature">
                                                        <h6 class="single-pack-feature__title">800 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>

                                                    <div class="single-pack-feature single-pack-feature--colored">
                                                        <h6 class="single-pack-feature__title">900 Mbps is good for
                                                        </h6>
                                                        <ul class="single-pack-feature-list">
                                                            <li>Up to 11 devices</li>
                                                            <li>Fast downloads</li>
                                                            <li>HD streaming</li>
                                                            <li>Multiplayer gaming</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="special-offer">
                                                    <img src="assets/img/feature-list/feature-list-vertical-2.png"
                                                        alt="xFi" class="special-offer__img">
                                                    <div class="special-offer__info">
                                                        <span class="special-offer__title">Add an xFi Gateway at
                                                            checkout</span>
                                                        <span class="special-offer__subtitle">Enjoy a powerful,
                                                            secure
                                                            connection.</span>
                                                    </div>

                                                    <span class="special-offer__price">$18/mo</span>
                                                </div>
                                            </div>

                                            <div class="col-lg-5">
                                                <img src="assets/img/package/package.jpg" alt="people using phone"
                                                    class="package-details__img">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!----------------- PACKAGE SECTION ENDS ----------------->


        <!----------------- TV SHOW/SPORTS SECTION STARTS ----------------->
        <!-- <section id="liveTV-section" class="pt-120 pb-60">
            <div class="container"> -->
        <!-- section heading end -->
        <!-- <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section-heading text-center mb-60">
                            <h2 class="ba-section-title section-title">Tv Show Sports & Live</h2>
                            <p class="liveTV__txt">Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga
                                exercitationem laboriosam omnis earum modi expedita amet?</p>
                        </div>
                    </div>
                </div> -->
        <!-- section heading end -->

        <!-- <div class="row justify-content-center">
                    <div class="col-lg-3 col-sm-6 col-10">
                        <div class="single-stream">
                            <div class="single-stream__img-container">
                                <img src="assets/img/stream/stream-1.jpg" alt="singer" class="single-stream__img">
                                <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                    class="video-popup stream-popup-btn">
                                    <i class="fas fa-play-circle"></i>
                                </a>
                            </div>

                            <h5 class="single-stream__title">Live Concert California</h5>
                            <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                class="single-stream__btn video-popup">
                                streaming <i class="fal fa-long-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6 col-10">
                        <div class="single-stream">
                            <div class="single-stream__img-container">
                                <img src="assets/img/stream/stream-2.jpg" alt="football-player"
                                    class="single-stream__img">
                                <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                    class="video-popup stream-popup-btn">
                                    <i class="fas fa-play-circle"></i>
                                </a>
                            </div>
                            <h5 class="single-stream__title">Watch Premier League</h5>
                            <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                class="single-stream__btn video-popup">
                                streaming <i class="fal fa-long-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6 col-10">
                        <div class="single-stream">
                            <div class="single-stream__img-container">
                                <img src="assets/img/stream/stream-3.jpg" alt="tiger" class="single-stream__img">
                                <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                    class="video-popup stream-popup-btn">
                                    <i class="fas fa-play-circle"></i>
                                </a>
                            </div>
                            <h5 class="single-stream__title">Discovery Channel 2022</h5>
                            <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                class="single-stream__btn video-popup">
                                streaming <i class="fal fa-long-arrow-right"></i>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6 col-10">
                        <div class="single-stream">
                            <div class="single-stream__img-container">
                                <img src="assets/img/stream/stream-4.jpg" alt="movie-poster" class="single-stream__img">
                                <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                    class="video-popup stream-popup-btn">
                                    <i class="fas fa-play-circle"></i>
                                </a>
                            </div>
                            <h5 class="single-stream__title">Elevated Action Movies</h5>
                            <a href="https://www.youtube.com/watch?v=93FKMoZZETw"
                                class="single-stream__btn video-popup">
                                streaming <i class="fal fa-long-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div> -->

        <!-- <a href="#" class="custom-btn">View More</a>
            </div>
        </section> -->
        <!----------------- TV SHOW/SPORTS SECTION ENDS ----------------->


        <!----------------- CONTACT SECTION STARTS ----------------->
        <!-- <section id="contact-section" class="pt-60 position-relative">
            <div class="container">
                <div class="conatct-section-bg">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="contact-section-form-container">
                                <h2 class="ba-section-title">Free Online Quote Now!</h2>
                                <form action="#" class="contact-form">
                                    <div class="contact-form__input-fields">
                                        <div class="input-field-container-name">
                                            <input type="text" name="contact-name" id="contact-form__name"
                                                placeholder="Your Name">
                                        </div>

                                        <div class="input-field-container-email">
                                            <input type="email" name="contact-email" id="contact-form__email"
                                                placeholder="Email ID">
                                        </div>

                                        <div class="input-field-container-number">
                                            <input type="number" name="contact-number" id="contact-form__number"
                                                placeholder="Phone No.">
                                        </div>

                                        <div class="input-field-container-subject">
                                            <input type="text" name="contact-subject" id="contact-form__subject"
                                                placeholder="Subject">
                                        </div>

                                        <div class="input-field-container-message">
                                            <textarea name="contact-textarea" id="contact-form__message"
                                                placeholder="Your Message" rows="5"></textarea>
                                        </div>
                                    </div>
                                    <button type="submit" class="ba-submit-btn">Send Message</button>
                                </form>
                            </div>
                        </div>

                        <div class="col-lg-6 position-relative">
                            <img src="assets/img/user/person.png" alt="person" class="conatct-img">
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!----------------- CONTACT SECTION ENDS ----------------->


        <!----------------- STATICS SECTION STARTS ----------------->
        <!-- <section id="stats-section" class="bg-default pb-110" data-background="assets/img/bg/statics.jpg">
            <div class="container">
                <div class="row justify-content-center justify-content-md-between gx-md-4 gx-2">
                    <div class="col-md-3 col-sm-4 col-6">
                        <div class="single-stat">
                            <h5 class="single-stat__number"><span class="odometer" data-count="260">0</span>k</h5>
                            <span class="single-stat__label">Internet Package</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-6">
                        <div class="single-stat">
                            <h5 class="single-stat__number"><span class="odometer" data-count="101">0</span>k</h5>
                            <span class="single-stat__label">Satisfaction Clients</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-6">
                        <div class="single-stat">
                            <h5 class="single-stat__number"><span class="odometer" data-count="2145">0</span></h5>
                            <span class="single-stat__label">Available Channels</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-6">
                        <div class="single-stat">
                            <h5 class="single-stat__number"><span class="odometer" data-count="1300">0</span></h5>
                            <span class="single-stat__label">Projects Completed</span>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!----------------- STATICS SECTION ENDS ----------------->


        <!----------------- TEAM SECTION STARTS ----------------->
        <!-- <div class="team-area pt-115 pb-120">
            <div class="container">
                <div class="row justify-content-center pb-60">
                    <div class="col-xxl-6 col-xl-7 col-lg-9">
                        <div class="ba-section-title-wrapper text-center">
                            <h3 class="ba-section-title pb-12">Professional Team</h3>
                            <p class="ba-mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                                eiusmod
                                te incididunt ut labore et dolore magna aliqua. Ut enim ad minim to saidul </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-team-card-box wow fadeInUp" data-wow-delay=".1s">
                            <div class="image">
                                <a href="team-details.php">
                                    <img src="assets/img/team/team-1.jpg" alt="person">
                                </a>
                            </div>
                            <div class="content text-center">
                                <h5 class="ba-team-card-box-title"><a href="team-details.php">Mohammad Rizwan</a>
                                </h5>
                                <a href="team-details.php" class="ba-team-card-box-designation">Marketing
                                    Officar</a>
                                <div class="ba-team-card-box-social">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-team-card-box wow fadeInUp" data-wow-delay=".2s">
                            <div class="image">
                                <a href="team-details.php">
                                    <img src="assets/img/team/team-2.jpg" alt="person">
                                </a>
                            </div>
                            <div class="content text-center">
                                <h5 class="ba-team-card-box-title"><a href="team-details.php">Alyssa Healy</a></h5>
                                <a href="team-details.php" class="ba-team-card-box-designation">Web Developer</a>
                                <div class="ba-team-card-box-social">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-team-card-box wow fadeInUp" data-wow-delay=".3s">
                            <div class="image">
                                <a href="team-details.php">
                                    <img src="assets/img/team/team-3.jpg" alt="person">
                                </a>
                            </div>
                            <div class="content text-center">
                                <h5 class="ba-team-card-box-title"><a href="team-details.php">Mohammad Haris</a>
                                </h5>
                                <a href="team-details.php" class="ba-team-card-box-designation">Developer</a>
                                <div class="ba-team-card-box-social">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-team-card-box wow fadeInUp" data-wow-delay=".4s">
                            <div class="image">
                                <a href="team-details.php">
                                    <img src="assets/img/team/team-4.jpg" alt="person">
                                </a>
                            </div>
                            <div class="content text-center">
                                <h5 class="ba-team-card-box-title"><a href="team-details.php">Natalie Sciver</a>
                                </h5>
                                <a href="team-details.php" class="ba-team-card-box-designation">Manager </a>
                                <div class="ba-team-card-box-social">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!----------------- TEAM SECTION ENDS ----------------->


        <!----------------- MOVIE SECTION STARTS ----------------->
        <!-- <section class="movie-area bg-default pb-120 pt-110" data-background="assets/img/movie/movie-2.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-xl-6 col-lg-6 pb-50 pb-lg-0">
                        <div class="ba-movie-content movie-section__content pr-185">
                            <h4 class="ba-movie-title wow fadeInUp movie-content__title" data-wow-delay=".1s">Enjoy
                                Sports Movies,<br> TV
                                Shows & More</h4>
                            <p class="wow fadeInUp movie-content__txt" data-wow-delay=".2s">Nisi utm aliquip sed
                                tempor
                                duis aute lorem
                                ipsum dolor sitye ametautys adipisicing elit sed dolor eiusmod </p>
                            <div class="ba-movie-price-service-duration-wrap pb-40 wow fadeInUp" data-wow-delay=".3s">
                                <h5 class="ba-movie-price movie-content__price">30$/ <span>1 Month</span></h5>
                                <div class="ba-movie-service-duration movie-content__duration">
                                    <i class="fal fa-router"></i>
                                    <span>1month WIFi Free</span>
                                </div>
                            </div>
                            <a href="contact.php" class="ba-submit-btn wow fadeInUp" data-wow-delay=".4s">Cheak
                                Availibilty</a>
                        </div>
                    </div>

                    <div class="col-xxl-6 col-xl-6 col-lg-6 pb-60">
                        <div class="position-relative h-100">
                            <div class="ba-feature-list-play-btn has-pos movie-section__play-btn">
                                <a href="https://www.youtube.com/watch?v=93FKMoZZETw" class="video-popup">
                                    <i class="fas fa-play"></i>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section> -->
        <!----------------- MOVIE SECTION ENDS ----------------->


        <!----------------- FAQ SECTION STARTS ----------------->
        <!-- <div id="index-1-faq-section" class="faq-area pt-115 pb-120">
            <div class="container">
                <div class="row align-items-center">

                    <div class="col-lg-6 mb-50 mb-lg-0">
                        <div class="faq-img mt-150">
                            <img src="assets/img/faq/faq.png" alt="map-icon">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="ba-faq-left-content">
                            <div class="ba-section-title-wrapper-top pb-40">
                                <div class="ba-section-title-wrapper pb-25">
                                    <h5 class="ba-section-subtitle wow fadeInUp" data-wow-delay=".1s">FAQ ASKED</h5>
                                    <h3 class="ba-section-title wow fadeInUp" data-wow-delay=".2s">Want to Ask
                                        Something
                                        from Us?</h3>
                                </div>
                                <p class="ba-mb-0 wow fadeInUp" data-wow-delay=".3s">Asi enim ad minim veniam, quis
                                    nostrud exerci Lorem ipsum dolor sit amet,<br> consecteturadipisicing elit, sed
                                    do
                                    eiusmod tempor</p>
                            </div>
                            <div class="ba-faq-accordion">
                                <div class="accordion" id="ba-faq-accordion">
                                    <div class="accordion-item wow fadeInUp" data-wow-delay=".4s">
                                        <h2 class="accordion-header" id="ba-accordion-heading-1">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#ba-collapse-1" aria-expanded="true"
                                                aria-controls="ba-collapse-1">
                                                Do I have to be an existing T-Mobile customer?
                                            </button>
                                        </h2>
                                        <div id="ba-collapse-1" class="accordion-collapse collapse show"
                                            aria-labelledby="ba-accordion-heading-1" data-bs-parent="#ba-faq-accordion">
                                            <div class="accordion-body">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                                                    eiusmod tempor incididunt ut labore dolore magna ali Ut enim ad
                                                    minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat. Duis aute irures dolor in
                                                    reprehenderit in voluptate velit esse cillum dolore eu fugiat
                                                    nul
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item wow fadeInUp" data-wow-delay=".5s">
                                        <h2 class="accordion-header" id="ba-accordion-heading-2">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#ba-collapse-2"
                                                aria-expanded="false" aria-controls="ba-collapse-2">
                                                What is a commercial on-line service?
                                            </button>
                                        </h2>
                                        <div id="ba-collapse-2" class="accordion-collapse collapse"
                                            aria-labelledby="ba-accordion-heading-2" data-bs-parent="#ba-faq-accordion">
                                            <div class="accordion-body">
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                                                eiusmod
                                                tempor incididunt ut labore dolore magna ali Ut enim ad minim
                                                veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                                commodo
                                                consequat. Duis aute irures dolor in reprehenderit in voluptate
                                                velit
                                                esse cillum dolore eu fugiat nul
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item wow fadeInUp" data-wow-delay=".6s">
                                        <h2 class="accordion-header" id="ba-accordion-heading-3">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#ba-collapse-3"
                                                aria-expanded="false" aria-controls="ba-collapse-3">
                                                24 Hours - Technical Support
                                            </button>
                                        </h2>
                                        <div id="ba-collapse-3" class="accordion-collapse collapse"
                                            aria-labelledby="ba-accordion-heading-3" data-bs-parent="#ba-faq-accordion">
                                            <div class="accordion-body">
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                                                eiusmod
                                                tempor incididunt ut labore dolore magna ali Ut enim ad minim
                                                veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                                commodo
                                                consequat. Duis aute irures dolor in reprehenderit in voluptate
                                                velit
                                                esse cillum dolore eu fugiat nul
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item wow fadeInUp" data-wow-delay=".7s">
                                        <h2 class="accordion-header" id="ba-accordion-heading-4">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#ba-collapse-4"
                                                aria-expanded="false" aria-controls="ba-collapse-4">
                                                When do you expect to roll out more markets?
                                            </button>
                                        </h2>
                                        <div id="ba-collapse-4" class="accordion-collapse collapse"
                                            aria-labelledby="ba-accordion-heading-4" data-bs-parent="#ba-faq-accordion">
                                            <div class="accordion-body">
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                                                eiusmod
                                                tempor incididunt ut labore dolore magna ali Ut enim ad minim
                                                veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                                commodo
                                                consequat. Duis aute irures dolor in reprehenderit in voluptate
                                                velit
                                                esse cillum dolore eu fugiat nul
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!----------------- FAQ SECTION ENDS ----------------->


        <!----------------- CTA/NEWSLETTER SECTION STARTS ----------------->
        <section id="nws-section" class=" mt-60 pt-60 pb-60 bg-default">
            <div class="container">
                <div class="row justify-content-lg-between justify-content-center align-items-center">
                    <div class="col-xxl-5 col-lg-7 col-md-10 col-sm-12">
                        <div class="nwsletter-content d-flex align-items-center">
                            <img src="assets/img/icons/nwsletter.png" alt="mail-icon" class="nwsletter-icon">
                            <div class="nwsletter-txt">
                                <h3>Check ability to connect our services in your area
                                </h3>
                                <span class="nwsletter-subtitle">IT IS A LONG ESTABLISHED FACT THAT A READER WILL BE
                                    DISTRACTED</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-lg-5 col-md-10 col-sm-12">
                        <form action="#" class="nwsletter-form">
                            <input type="email" name="nwsletter-email" id="nwsletter-email" class="nwsletter-email"
                                placeholder="Enter Your Email">
                            <button type="submit" class="nwsletter-btn">Get Started</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!----------------- CTA/NEWSLETTER SECTION ENDS ----------------->


        <!----------------- TESTIMONIAL SECTION STARTS ----------------->
        <section id="testimonial-section" class="pt-115 pb-120 overflow-hidden">
            <div class="container">
                <div class="row justify-content-center pb-60">
                    <div class="col-xl-6 col-lg-8 col-md-10">
                        <div class="text-center">
                            <h3 class="ba-section-title">What our clients say
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12">
                        <div class="testimonial-slider-container">
                            <div class="swiper mySwiper overflow-hidden">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="single-testimonial">
                                            <div class="stars">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fad fa-star"></i>
                                            </div>

                                            <p class="single-testimonial__txt">
                                                "I was blown away by the variety of internet and TV bundles offered by
                                                TVBundlesOnline.com. Their customer service was top-notch, helping me
                                                find the perfect plan for my needs. I ended up saving $30/month by
                                                switching to their recommended bundle. Highly recommend!"
                                            </p>

                                            <div class="testimonial-writer d-flex">
                                                <img src="assets/img/user/img-3.jpg" alt="person"
                                                    class="testimonial-writer__img">
                                                <div class="testimonial-writer__info">
                                                    <h6 class="testimonial-writer__name">-Emily R.</h6>
                                                    <!-- <span class="testimonial-writer__label">Rental Customer</span> -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- <div class="swiper-slide">
                                        <div class="single-testimonial">
                                            <div class="stars">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="far fa-star"></i>
                                            </div>

                                            <p class="single-testimonial__txt">
                                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi eaque
                                                voluptate,
                                                exercitationem temporibus velit tempora quidem totam, corrupti
                                                accusamus
                                                facilis
                                                consequuntur qui consequatur pariatur. Ea minima ab et quo ad!
                                            </p>

                                            <div class="testimonial-writer d-flex">
                                                <img src="assets/img/user/user-4.png" alt="person"
                                                    class=" testimonial-writer__img">
                                                <div class="testimonial-writer__info">
                                                    <h6 class="testimonial-writer__name">beth moony</h6>
                                                    <span class="testimonial-writer__label">customer</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="single-testimonial">
                                            <div class="stars">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fad fa-star-half"></i>
                                            </div>

                                            <p class="single-testimonial__txt">
                                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi eaque
                                                voluptate,
                                                exercitationem temporibus velit tempora quidem totam, corrupti
                                                accusamus
                                                facilis
                                                consequuntur qui consequatur pariatur. Ea minima ab et quo ad!
                                            </p>

                                            <div class="testimonial-writer d-flex">
                                                <img src="assets/img/user/user-1.png" alt="person"
                                                    class="testimonial-writer__img">
                                                <div class="testimonial-writer__info">
                                                    <h6 class="testimonial-writer__name">beth moony</h6>
                                                    <span class="testimonial-writer__label">customer</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div> -->
                                </div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!----------------- TESTIMONIAL SECTION ENDS ----------------->

        <section id="nws-section" class=" mt-60 pt-60 pb-60 bg-default news__section">
            <div class="container">
                <div class="row justify-content-lg-between justify-content-center align-items-center">
                    <div class="col-xxl-5 col-lg-7 col-md-10 col-sm-12">
                        <div class="nwsletter-content d-flex align-items-center">
                            <img src="assets/img/icons/nwsletter.png" alt="mail-icon" class="nwsletter-icon">
                            <div class="nwsletter-txt">
                                <h3>Subscribe Now
                                </h3>
                                <!-- <span class="nwsletter-subtitle">IT IS A LONG ESTABLISHED FACT THAT A READER WILL BE DISTRACTED</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-lg-5 col-md-10 col-sm-12">
                        <form action="#" class="nwsletter-form">
                            <input type="email" name="nwsletter-email" id="nwsletter-email" class="nwsletter-email"
                                placeholder="Enter Your Email">
                            <button type="submit" class="nwsletter-btn">Get Started</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!----------------- BLOG SECTION STARTS ----------------->
        <!-- <div class="ba-blog-area pb-120 pt-115" data-bg-color="#f9f9f9">
            <div class="container">
                <div class="row pb-60">
                    <div class="col-xxl-12">
                        <div class="ba-section-title-wrapper text-center ba-has-wrapped-br">
                            <h3 class="ba-section-title">Read Our Recent<br> Blog Posts</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-blog-box-transparent ba-blog-box-transparent-height bg-default wow fadeInUp"
                            data-wow-delay=".1s" data-background="assets/img/bg/blog.png">
                            <div class="ba-blog-box-content">
                                <div class="ba-blog-box-meta-wrapper">
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fas fa-user"></i>
                                        <a href="blog-details.php">Bailey Turner</a>
                                    </div>
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fal fa-calendar"></i>
                                        <span>Apr 25, 2022</span>
                                    </div>
                                </div>
                                <h4 class="ba-blog-box-title"><a href="blog-details.php">Broadband Connection
                                        Needs<br>
                                        To Everyone Life</a></h4>
                                <p>We help ambitious businesses like yours generate more profits </p>
                                <a href="blog-details.php" class="read-more-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6 mb-30 mb-xl-0">
                        <div class="ba-blog-box-solid-white  wow fadeInUp" data-wow-delay=".2s">
                            <div class="ba-blog-box-img">
                                <a href="blog-details.php"><img src="assets/img/blog/blog-box-1.png"
                                        alt="girl-lying"></a>
                            </div>
                            <div class="ba-blog-box-content">
                                <div class="ba-blog-box-meta-wrapper">
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fas fa-user"></i>
                                        <a href="blog-details.php">Lydia Webster</a>
                                    </div>
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fal fa-calendar"></i>
                                        <span>July 11, 2022</span>
                                    </div>
                                </div>
                                <h4 class="ba-blog-box-title"><a href="blog-details.php">Children Loves the
                                        Cartoons<br> And Our New Channels</a></h4>
                                <p>We help ambitious businesses like yours generate more profits </p>
                                <a href="blog-details.php" class="read-more-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 mb-30 mb-xl-0">
                        <div class="ba-blog-box-list-wrapper wow fadeInUp" data-wow-delay=".3s">
                            <div class="ba-blog-box-list-item">
                                <div class="ba-blog-box-meta-wrapper">
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fas fa-user"></i>
                                        <a href="blog-details.php">Ashley Parker</a>
                                    </div>
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fal fa-calendar"></i>
                                        <span>Dec 15, 2021</span>
                                    </div>
                                </div>
                                <h4 class="ba-blog-box-title"><a href="blog-details.php">Watch Your Favorite Racing
                                        <br>Sport Channels!</a></h4>
                            </div>
                            <div class="ba-blog-box-list-item">
                                <div class="ba-blog-box-meta-wrapper">
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fas fa-user"></i>
                                        <a href="blog-details.php">Manuel Davidson</a>
                                    </div>
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fal fa-calendar"></i>
                                        <span>Aug 1, 2022</span>
                                    </div>
                                </div>
                                <h4 class="ba-blog-box-title"><a href="blog-details.php">At vero eos et accusamus
                                        et<br> iusto odio dignissimos</a></h4>
                            </div>
                            <div class="ba-blog-box-list-item">
                                <div class="ba-blog-box-meta-wrapper">
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fas fa-user"></i>
                                        <a href="blog-details.php">Hayden Taylor</a>
                                    </div>
                                    <div class="ba-blog-box-meta-single">
                                        <i class="fal fa-calendar"></i>
                                        <span>Jul 7, 2022</span>
                                    </div>
                                </div>
                                <h4 class="ba-blog-box-title"><a href="blog-details.php">When Movie Stars Switch
                                        to<br>
                                        Reality TV Shows</a></h4>
                            </div>
                            <div class="ba-blog-box-list-action-btn pt-10">
                                <a href="blog-details.php" class="ba-submit-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!----------------- BLOG SECTION ENDS ----------------->
    </main>

    <footer id="footer-section">
        <div class="container">

            <!-- FOOTER ONE STARTS HERE -->
            <div class="footer-one">
                <div class="row justify-content-between">
                    <div class="col-xxl-4 col-xl-5 col-lg-6">
                        <!-- <div class="footer-heading">
                            <h3>We Are Your Instagram Best Solution</h3>
                        </div> -->
                    </div>

                    <!-- <div class="col-xxl-5 col-xl-6 col-lg-6">
                        <div class="footer-img-container">
                            <a href="assets/img/bg/service.png" class="image-popups">
                                <img src="assets/img/bg/service.png" alt="girls-using-phone" class="footer-img">
                            </a>
                            <a href="assets/img/about/about-1.jpg" class="image-popups">
                                <img src="assets/img/about/about-1.jpg" alt="2 people watching tab" class="footer-img">
                            </a>
                            <a href="assets/img/blog/blog-box-1.png" class="image-popups">
                                <img src="assets/img/blog/blog-box-1.png" alt="girl-lying" class="footer-img">
                            </a>
                            <a href="assets/img/blog/blog-details-1.jpg" class="image-popups">
                                <img src="assets/img/blog/blog-details-1.jpg" alt="people using laptop"
                                    class="footer-img">
                            </a>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- FOOTER ONE ENDS HERE -->


            <!-- FOOTER TWO STARTS HERE -->
            <div class="footer-two">
                <div class="row justify-content-xl-between justify-content-center">
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="company-info">
                            <img src="assets/img/logo/logo-3.png" alt="logo" class="footer-two__logo">

                            <div class="company-info__txt">
                                <h3 class="ba-footer-widget-title footer-two-widget__title">
                                    CUSTOMER SERVICE
                                </h3>
                                <p>
                                    At Tv Bundles Online, we pride ourselves on delivering top-notch customer service
                                    that exceeds our clients' expectations.
                                </p>
                                <!-- <span>O PBox 1622 Vissaosang Street West </span> -->

                                <!-- <div class="company__numbers">
                                    <a href="tel:9145789658424">+9145789658424 ,</a>
                                    <a href="tel:6157845625">+6157845625</a>
                                </div> -->

                                <!-- <span>minimart@domain.com</span>
                                <span>Opening Hours : 8.00AM - 21.00AM</span>
                                <span>Sunday - Friday</span> -->
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-3 col-6">
                        <div class="ba-footer-widget footer-two-widget">
                            <h3 class="ba-footer-widget-title footer-two-widget__title">LET US HELP YOU</h3>
                            <p>
                                Ask a question
                                Request support
                                Learn more about our products and services
                                Get started with a custom solution
                            </p>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-3 col-6">
                        <div class="ba-footer-widget footer-two-widget">
                            <h3 class="ba-footer-widget-title footer-two-widget__title">INFORMATION </h3>
                            <ul>
                                <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                                <!-- <li><a href="blog-details.php">Blog Details</a></li>
                                <li><a href="team.php">Team</a></li>
                                <li><a href="team-details.php">Team Details</a></li> -->
                            </ul>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-8">
                        <div class="ba-footer-widget footer-two-widget footer-two-widget--last pr-50">
                            <h3 class="ba-footer-widget-title footer-two-widget__title">OUR SHOP</h3>
                            <div class="ba-footer-widget-working-hours-list footer-two-widget__working-hours">
                              <p>
                                Experience crystal-clear picture quality and reliable service with our state-of-the-art cable technology.
                              </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- FOOTER TWO ENDS HERE -->

            <!-- FOOTER THREE STARTS HERE -->
            <div class="footer-three pt-35 pb-40">
                <div class="row">
                    <div class="col-md-6">
                        <p class="ba-footer-copyright-text footer-three__copyright-text">Copyright &copy; 2022 All
                            rights reserved.</p>
                    </div>
                    <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                        <img src="assets/img/payment-method/payment-method.png" alt="logo" class="payment-methods">
                    </div>
                </div>
            </div>
            <!-- FOOTER THREE ENDS HERE -->
        </div>
    </footer>

    <!-- back to top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- back to top end -->



    <!-- JS FILES -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/meanmenu.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/magnific-popup.min.js"></script>
    <script src="assets/js/jquery-ui-slider-range.js"></script>
    <script src="assets/js/appair.min.js"></script>
    <script src="assets/js/odometer.min.js"></script>
    <script src="assets/js/backToTop.js"></script>
    <script src="assets/js/nice-select.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/main.js"></script>

    <script>
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            breakpoints: {
                768: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
            }
        });
    </script>
</body>

</html>