<?php include 'include/header.php';?>
  <main id="main">


   

 <!-- ======= Features Section ======= -->
    <section class="features">
      <div class="container">

        <div class="section-title">
          <h2>Thank You</h2>
          <p>We Will Get In Touch With You Soon...</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5 mx-auto">
            <img src="https://cdn.pixabay.com/animation/2023/03/19/19/55/19-55-58-835_512.gif" class="img-fluid" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

  </main><!-- End #main -->

<?php include 'include/footer.php';?>