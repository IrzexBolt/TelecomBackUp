<?php include 'include/header.php';?>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-cntent-center align-items-center">
    <div id="heroCarousel" class="container carousel carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

      <!-- Slide 1 -->
      <div class="carousel-item active">
        <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">Your Ultimate Connectivity   <span>Suite</span></h2>
          <p class="animate__animated animate__fadeInUp">Grasp the quintessential blend of infinite entertainment, high speed internet, and reliable telecom services under one roof. </p>
          <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
        </div>
      </div>

      <!-- Slide 2 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">Seamless Wireless and Reliable <br> Home Security Services </h2>
          <p class="animate__animated animate__fadeInUp">Enjoy seamless connectivity across devices with cutting-edge Wireless internet connection, and secure your premises with robust home security systems. </p>
          <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
        </div>
      </div>

      <!-- Slide 3 -->
      <div class="carousel-item">
        <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">Ready to Join the Streaming Revolution </h2>
          <p class="animate__animated animate__fadeInUp">Wave Farewell to buffering and hello to binge watching with exclusive bundles and deals on super-fast internet and high-definition television services. </p>
          <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
        </div>
      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= Services Section ======= -->
    <section class="services">
      <div class="container">

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <div class="icon"><img src="assets/img/icons/1.svg" class="img-fluid" alt=""></div>
              <h4 class="title"><a href="">Check the Coverage Area </a></h4>
              <p class="description">Click now to confirm your location is within our coverage area.</p>
                <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box icon-box-cyan">
              <div class="icon"><img src="assets/img/icons/5.svg" class="img-fluid" alt=""></div>
              <h4 class="title"><a href="">Compare Different Plans </a></h4>
              <p class="description">Discover and compare different plans, to select the one that best fits your needs. </p>
               <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-green">
              <div class="icon"><img src="assets/img/icons/3.svg" class="img-fluid" alt=""></div>
              <h4 class="title"><a href="">Pick the Preferred Plan or Package </a></h4>
              <p class="description">Choose the plan that aligns with your entertainment and connectivity preferences. </p>
                <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box icon-box-blue">
              <div class="icon"><img src="assets/img/icons/4.svg" class="img-fluid" alt=""></div>
              <h4 class="title"><a href="">Place Your Order </a></h4>
              <p class="description">Hit the call button now and enjoy uninterrupted digital experience.</p>
                <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Why Us Section ======= -->
    <!-- <section class="why-us section-bg" data-aos="fade-up" date-aos-delay="200">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 video-box">
            <img src="assets/img/why-us.jpg" class="img-fluid" alt="">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-6 d-flex flex-column justify-content-center p-5">

            <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Lorem Ipsum</a></h4>
              <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="bx bx-gift"></i></div>
              <h4 class="title"><a href="">Nemo Enim</a></h4>
              <p class="description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque</p>
            </div>

          </div>
        </div>

      </div>
    </section> -->
    <!-- End Why Us Section -->

    <!-- ======= Features Section ======= -->
    <section class="features">
      <div class="container">

        <div class="section-title">
          <h2>Comprehensive Digital Services for <br> Seamless Connectivity</h2>
          <p>Make the switch to unmatched and top-tier cable TV, Wireless internet, telecom and home security services designed specifically for your peace of mind and ultimate convenience. </p>
           <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/features-1.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-4 my-auto">
            <h3>Supercharge Your Browsing Experience with Blazing Fast Internet Plans</h3>
            <p class="fst-italic">
            Enjoy unparalleled online experiences with our lightning-fast internet bundles and packages. From casual surfers to high-stake gamers, our diverse internet offerings cater to specific connectivity demands of each individual. 
            </p>
             <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/features-2.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1 my-auto">
            <h3>Explore Infinite Viewing Possibilities with Premium Cable TV Services </h3>
            <p class="fst-italic">
            Experience a new era of ultimate TV entertainment with unmatched cable TV services offerings and plans. Whether you’re a cinephile, sports fanatic, or a fashion enthusiast our diverse range of television packages are custom-tailored to fit every preference and lifestyle. 
            </p>
             <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/features-3.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 my-auto">
            <h3>Elite Home Security Solutions for a Total Peace of Mind </h3>
            <p>Turn your home into a guarded retreat and enjoy a complete peace of mind with our comprehensive and hassle-free home security services. Our advanced and easy to use technology, coupled with 24/7 support guarantee ultimate safety of your home. </p>
             <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
          </div>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="assets/img/features-4.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 order-2 order-md-1 my-auto">
            <h3>Unparalleled Wireless Phone Services for Every Phone and Lifestyle </h3>
            <p>
            Say aloha to one-size fits all and adieu to custom wireless phone packages. Whether you’re a talkative soul, or a data devourer our wireless phone packages are tailored to meet your individual preferences and needs. 
            </p>
             <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
          </div>
        </div>
        <div class="row" data-aos="fade-up">
          <div class="col-md-5">
            <img src="assets/img/features-5.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 my-auto">
            <h4>Early Bird Perks</h4>
            <h3>Save Big on Your First Sign-Up  </h3>
            <p>Sign-up today and enjoy up-to 30% discount on our blazing-fast internet, premium cable TV, robust home security, and reliable wireless telephone services.</p>
            <p>Act Now and Enjoy Exclusive Discounts and Savings.</p> 
             <a href="tel:+18884844117" class="btn-get-started animate__animated animate__fadeInUp">Call Now</a>
        </div>
        </div>

      </div>
    </section><!-- End Features Section -->

  </main><!-- End #main -->
<?php include 'include/footer.php';?>