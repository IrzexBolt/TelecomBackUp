<?php include 'include/header.php'; ?>

<main id="main">

    <!-- ======= Contact Section ======= -->
    <section class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
                <h1><b>Contact</b></h1>
                <ol>
                    <li><a href="index.php">Home</a></li>
                    <li>Contact</li>
                </ol>
            </div>

        </div>
    </section><!-- End Contact Section -->

    <!-- ======= Contact Section ======= -->
    <section class="contact" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">
        <div class="container">

            <div class="row">

                <div class="col-lg-6">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-box">
                                <i class="bx bx-envelope"></i>
                                <h3>Email Us</h3>
                                <p><a href="mailto:info@internetbundlesonline.com">info@internetbundlesonline.com</a>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-box">
                                <i class="bx bx-phone-call"></i>
                                <h3>Call Us</h3>
                                <p><a href="tel:+18665840782">+1 866 584 0782</a></p>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-6">
                    <form action="/sendmail/" method="post" class="form-content">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name"
                                    required>
                            </div>
                            <div class="col-md-6 form-group mt-3 mt-md-0">
                                <input type="email" class="form-control" name="email" id="email"
                                    placeholder="Your Email" required>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <input type="number" class="form-control" name="phone" id="subject"
                                placeholder="Contact No." required>
                        </div>
                        <div class="form-group mt-3">
                            <textarea class="form-control" name="msg" rows="5" placeholder="Message"
                                required></textarea>
                        </div>
                        <div class="text-center mt-3"><button type="submit">Send Message</button></div>
                    </form>
                </div>

            </div>

            <div class="row mt-5">
                <div class="col-lg-12">
                    <h2>Our Internet Services</h2>
                    <p>We offer a wide range of internet services designed to meet the needs of both residential and
                        business customers. Our offerings include high-speed internet, reliable connectivity, and
                        affordable plans. Whether you are streaming your favorite shows, working from home, or running a
                        business, we have the right internet solution for you.</p>
                    <ul>
                        <li><b>High-Speed Internet:</b> Enjoy lightning-fast internet speeds that ensure smooth
                            browsing, streaming, and downloading.</li>
                        <li><b>Reliable Connectivity:</b> Our services guarantee stable and reliable internet
                            connections, so you can stay connected without interruptions.</li>
                        <li><b>Affordable Plans:</b> Choose from a variety of affordable plans that fit your budget and
                            meet your internet usage needs.</li>
                        <li><b>24/7 Customer Support:</b> Our dedicated customer support team is available 24/7 to
                            assist you with any issues or questions.</li>
                    </ul>
                    <p>Contact us today to learn more about our internet services and how we can help you stay
                        connected.</p>
                </div>
            </div>

        </div>
    </section><!-- End Contact Section -->

</main><!-- End #main -->

<?php include 'include/footer.php'; ?>