<?php
$formtype = $_POST['contactform'];
$subject = " Contact Form | internetbundlesonline.com ";

$data = '<table style="width:100%; border: 1px solid black; border-collapse: collapse;">';
foreach ($_POST as $key => $value) {
	$_key = ucwords(str_replace('_', ' ', $key));
	$data .= '<tr><td style="border: 1px solid black; border-collapse: collapse; padding: 15px; text-align: left; font-size:15px; font-weight: 500;">' . $_key . '<td><td style=" border: 1px solid black; border-collapse: collapse; padding: 15px; text-align: left; font-size:15px">' . $value . '</td></tr>';
}
$data .= '</table>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$mailSent = mail('info@internetbundlesonline.com', $subject, $data, $headers);
if ($mailSent) {
	$output = json_encode(array('type' => 'message', 'text' => ''));
	header('Location: https://internetbundlesonline.com/thank-you');
	echo json_encode(['status' => '1', 'data' => 'Mail Sent']);
} else {
	$output = json_encode(array('type' => 'error', 'text' => 'Some Error Accure'));
	header('Location: https://internetbundlesonline.com/thank-you');
}
$output = json_encode(array('type' => 'message', 'text' => ''));
header('Location: https://internetbundlesonline.com/thank-you');

?>